﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IFProgrammeringsTest2.Models
{
    public class HomeModel
    {
        public string spelDatum { get; set; }
    }
}
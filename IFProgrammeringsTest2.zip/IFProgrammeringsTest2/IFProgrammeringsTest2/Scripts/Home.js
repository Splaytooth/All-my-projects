﻿/** 
Denna JS fil ska:
1. Hämta data från Debasers API utefter de sökord som har angivits.
2. Presentera datan i en tabell.

NOTERINGAR: 
- Borde ha haft med REGEX för att se till att inputten har korrekt format. Alternativt nån mer begränsande form av input istället för textfält. 
  Som det ser ut nu är användargränssnittet inte användarvänligt.
- AJAXen funkar ej. Tippar på att det handlar om same-origin policyn som blockar mig. Ska kolla mer på CORS(Cross-origin resource sharing) för att formulera URLen korrekt. 
  Även JSONP är något som ofta rekommenderas för detta problem.
  http://www.debaser.se/api/?method=getevents&venue=" + spelPlats + "&from=" + datumFran + "&to=" + datumTill + "&format=json
**/

$(document).ready(function () {
    $("#Result").click(function () {
        var eventsArray;
        var datumFran = document.getElementById("datumFran").value;
        var datumTill = document.getElementById("datumTill").value;
        var spelPlats = document.getElementById("spelplats").value;

        $.ajax({
            type: "GET",
            url: "http://www.debaser.se/api/?method=getevents&venue=" + spelPlats + "&from=" + datumFran + "&to=" + datumTill + "&format=json",
            dataType: 'json',
            success: function (data) {
                alert('Lyckat resultat');
                /**for (i = 0; i < data.length; i++) {
                    eventsArray[i] = new Array(data[i].event, data[i].venue, data[i].datum, data[i].description);
                }
                FillTable(eventsArray); **/
            },
            error: function (xhr, status, error) {
                alert("Hämtningen misslyckades"); 
            },
        });
        FillTable();
    });

    function FillTable(eventsArray) {
        // Eftersom Ajax delen inte funkar skapar jag en array med exempel värden som ska bearbetas och presenteras.
        var eventsArray = new Array();
        eventsArray[0] = new Array("Eric Saade", "Humlegården", "2018-04-13", "Se en av Sveriges mest älskade artister, han spelar bara en låt dock så kom inte hit.");
        eventsArray[1] = new Array("Annas Äventyr", "Medis", "2018-05-25", "Hur överlever man när man har blivit strandsatt? Följ hur Anna överlevde i hela 5 månader på en Ö!");
        eventsArray[2] = new Array("Vattenkrig", "Strand", "2018-05-15", "Dricka och vattenkrig!");

        for (i = 0; i < eventsArray.length; i++) {
            var tr = document.createElement('TR');
            for (j = 0; j < eventsArray[i].length; j++) {
                var td = document.createElement('TD');
                td.appendChild(document.createTextNode(eventsArray[i][j]));
                document.getElementById("tableResults").appendChild(td);
            }
            document.getElementById("tableResults").append(tr);
        }
    }
});
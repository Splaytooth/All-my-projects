
package javaapplication1;

import oru.inf.InfException;
import javax.swing.JOptionPane;


public class LäggTillKompetenser extends javax.swing.JFrame {

    
    public LäggTillKompetenser() {
        initComponents();
        setLocation(600, 300);
        setSize(640, 360);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfKompetens = new javax.swing.JTextField();
        tfPlattform = new javax.swing.JTextField();
        tfLevel = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnGaTillbaka = new javax.swing.JButton();
        btnUppdatera = new javax.swing.JButton();
        tfAnvandarNamn = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(tfKompetens);
        tfKompetens.setBounds(140, 110, 110, 30);
        getContentPane().add(tfPlattform);
        tfPlattform.setBounds(140, 150, 110, 30);
        getContentPane().add(tfLevel);
        tfLevel.setBounds(140, 190, 110, 30);

        jLabel1.setText("Kompetens");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 110, 70, 20);

        jLabel2.setText("Plattform");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(50, 150, 70, 20);

        jLabel3.setText("Level");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(60, 200, 50, 20);

        btnGaTillbaka.setText("Gå tillbaka");
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(520, 30, 90, 30);

        btnUppdatera.setText("Uppdatera");
        btnUppdatera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUppdateraMouseClicked(evt);
            }
        });
        getContentPane().add(btnUppdatera);
        btnUppdatera.setBounds(160, 240, 90, 30);
        getContentPane().add(tfAnvandarNamn);
        tfAnvandarNamn.setBounds(140, 70, 110, 30);

        jLabel4.setText("Användarnamn");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 70, 100, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnUppdateraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUppdateraMouseClicked
        // Uppdaterar en befintlig domän efter diverse kontroller och valideringar.
        if(!Validering.textNotEmpty2(tfAnvandarNamn) || !Validering.textNotEmpty2(tfKompetens) || !Validering.textNotEmpty2(tfPlattform) || !Validering.textNotEmpty2(tfLevel))
        {
            JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma.");
        }
        else
        {
            try
            {
             
                String level = tfLevel.getText();
                String anvAID  = TestAvDB.getIDB().fetchSingle("select ANSTALLD.AID FROM ANSTALLD WHERE anvnamn ='" + tfAnvandarNamn.getText() + "'");
               
                
                if(anvAID == null)
                {
                    JOptionPane.showMessageDialog(null, "Finns ingen anställd med det användarnamnet.");
                }
                else
                {
                    String hamtaKID = TestAvDB.getIDB().fetchSingle("Select kid from kompetensdoman where benamning = '" + tfKompetens.getText() + "'");
                    String hamtaPID = TestAvDB.getIDB().fetchSingle("select pid from plattform where benamning = '" + tfPlattform.getText() + "'");
                    if(hamtaKID == null)
                    {
                        JOptionPane.showMessageDialog(null, "Hittade ingen kompetens med denna benämning.");
                    }
                    
                    else if(hamtaPID == null)
                    {
                        JOptionPane.showMessageDialog(null, "Hittade ingen plattform med denna benämning.");
                    }
                    System.out.println("select * from HAR_KOMPETENS where aid ='" + anvAID +  "' and kid ='" + hamtaKID + "' and pid = '" + hamtaPID + "'");
                    String SQLfraga = TestAvDB.getIDB().fetchSingle("select * from HAR_KOMPETENS where aid ='" + anvAID +  "' and kid ='" + hamtaKID + "' and pid = '" + hamtaPID + "'");
                    
                    if(Validering.kollaINT(level) == false)
                    {
                        JOptionPane.showMessageDialog(null, "Kontrollera informationen som har matats in.\n Ta hänsyn till att level måste vara mellan 0-4"
                                 + " \n \n Exempel \n Användarnamn: ppt \n Kompetens: Art \n Plattform: Xbox \n Level: 3");
                    }
                    else if(SQLfraga != null)
                    {
                        JOptionPane.showMessageDialog(null, "Personen har redan denna kompetens.");
                    }
                   
                    else if(Integer.parseInt(level) <= 4 && Integer.parseInt(level) > 0)
                    {
                        String laggTill = "Insert into HAR_KOMPETENS(AID,KID,PID,KOMPETENSNIVA) values('" + anvAID + "','" + hamtaKID + "','" + hamtaPID + "','" + level + "')";
                        System.out.println(laggTill);
                        JOptionPane.showMessageDialog(null, "En kompetens har lagts till");
                        setVisible(false);
                        TestAvDB.getIDB().insert(laggTill);
                    }
                     
                    
                }
            }
            catch(InfException error)
            {
                System.out.println(error);
            }
        }
    }//GEN-LAST:event_btnUppdateraMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        //Stänger fönstret och går tillbaka
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LäggTillKompetenser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LäggTillKompetenser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LäggTillKompetenser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LäggTillKompetenser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>


        java.awt.EventQueue.invokeLater(() -> {
            new LäggTillKompetenser().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnUppdatera;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField tfAnvandarNamn;
    private javax.swing.JTextField tfKompetens;
    private javax.swing.JTextField tfLevel;
    private javax.swing.JTextField tfPlattform;
    // End of variables declaration//GEN-END:variables
}

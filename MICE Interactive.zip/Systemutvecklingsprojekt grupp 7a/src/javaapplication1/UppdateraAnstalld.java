package javaapplication1;

import java.math.BigInteger;
import oru.inf.InfException;
import java.security.SecureRandom;
import javax.swing.JOptionPane;

public class UppdateraAnstalld extends javax.swing.JFrame {
//Konstruktorn. Instansierar alla rutor man kan gå till från denna klass.
//Instansierar även en lösenords-generator.
    private LäggTillKompetenser kompetens;
    private SecureRandom random = new SecureRandom();
    private TaBortAnstalld sparka;
    
    public UppdateraAnstalld() {
        initComponents();
        kompetens = new LäggTillKompetenser();
        
        sparka = new TaBortAnstalld();
        sparka.setLocation(600, 300);
        sparka.setSize(640, 350);
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnTaBortAnstalld = new javax.swing.JButton();
        cbProjektledare = new javax.swing.JCheckBox();
        btnGaTillbaka = new javax.swing.JButton();
        cbSpecialist = new javax.swing.JCheckBox();
        btnRegistrera = new javax.swing.JButton();
        cbAdministratör = new javax.swing.JCheckBox();
        tfNamn = new javax.swing.JTextField();
        tfEfternamn = new javax.swing.JTextField();
        tfTelefon = new javax.swing.JTextField();
        tfMail = new javax.swing.JTextField();
        btnKompetenser = new javax.swing.JButton();
        tfAID = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Namn");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 80, 60, 20);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Efternamn");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(40, 110, 70, 20);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Telefon");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(40, 140, 60, 20);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Mail");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 170, 40, 20);

        btnTaBortAnstalld.setBackground(new java.awt.Color(153, 204, 255));
        btnTaBortAnstalld.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnTaBortAnstalld.setText("Ta bort anställd");
        btnTaBortAnstalld.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnTaBortAnstalld.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTaBortAnstalldMouseClicked(evt);
            }
        });
        getContentPane().add(btnTaBortAnstalld);
        btnTaBortAnstalld.setBounds(270, 210, 150, 30);

        cbProjektledare.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbProjektledare.setForeground(new java.awt.Color(255, 255, 255));
        cbProjektledare.setText("Projektledare");
        getContentPane().add(cbProjektledare);
        cbProjektledare.setBounds(290, 50, 100, 23);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(510, 40, 110, 30);

        cbSpecialist.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbSpecialist.setForeground(new java.awt.Color(255, 255, 255));
        cbSpecialist.setText("Specialist");
        getContentPane().add(cbSpecialist);
        cbSpecialist.setBounds(290, 80, 77, 23);

        btnRegistrera.setBackground(new java.awt.Color(153, 204, 255));
        btnRegistrera.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnRegistrera.setText("Uppdatera Anställd");
        btnRegistrera.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnRegistrera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistreraMouseClicked(evt);
            }
        });
        getContentPane().add(btnRegistrera);
        btnRegistrera.setBounds(110, 210, 150, 30);

        cbAdministratör.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbAdministratör.setForeground(new java.awt.Color(255, 255, 255));
        cbAdministratör.setText("Administratör");
        getContentPane().add(cbAdministratör);
        cbAdministratör.setBounds(290, 110, 120, 23);

        tfNamn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfNamn);
        tfNamn.setBounds(110, 80, 150, 20);

        tfEfternamn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfEfternamn);
        tfEfternamn.setBounds(110, 110, 150, 20);

        tfTelefon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfTelefon);
        tfTelefon.setBounds(110, 140, 150, 20);

        tfMail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfMail);
        tfMail.setBounds(110, 170, 150, 20);

        btnKompetenser.setBackground(new java.awt.Color(153, 204, 255));
        btnKompetenser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnKompetenser.setText("Lägg Till Kompetenser");
        btnKompetenser.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnKompetenser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnKompetenserMouseClicked(evt);
            }
        });
        getContentPane().add(btnKompetenser);
        btnKompetenser.setBounds(110, 250, 150, 30);

        tfAID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfAID);
        tfAID.setBounds(110, 50, 150, 20);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Vilken person? (användarnamn)");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(100, 30, 190, 20);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(0, 0, 960, 20);

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel4);
        jPanel4.setBounds(0, 330, 960, 20);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 0, 700, 370);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        //Går tillbaka. Stänger fönstret i fråga.
        this.setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked
    
    private void btnKompetenserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnKompetenserMouseClicked
        //Öppnar fönstret för kompetenser.
        kompetens.setVisible(true);
    }//GEN-LAST:event_btnKompetenserMouseClicked

    private void btnRegistreraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistreraMouseClicked
       //Kontrollerar inmatad information och uppdaterar sedan en anställd.
       //Genererar även ett lösenord om personen har valts som administratör.
        boolean registrerad = false;
       try
       {

        if(Validering.kontrolleraEmail(tfMail.getText()))
        {
            if(!Validering.textNotEmpty2(tfNamn) || !Validering.textNotEmpty2(tfEfternamn) || !Validering.textNotEmpty2(tfTelefon) || !Validering.textNotEmpty2(tfAID))
            {
                JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma. Alla information måste vara ifylld för att registreringen ska ske.");
            }
            else
            {
                String anvAID = TestAvDB.getIDB().fetchSingle("Select aid from anstalld where anvnamn = '" + tfAID.getText() + "'");
                String SQLfraga = "select anvnamn from anstalld where AID ='" + anvAID + "'";
                if(tfAID.getText().equalsIgnoreCase((TestAvDB.getIDB().fetchSingle(SQLfraga))))
            {
               boolean adminz = false;
               boolean projlead = false;
               boolean specialistz = false;

               if(Validering.textNotEmpty2(tfNamn) == true)
               {
                   String helanamnet = tfNamn.getText() + " " + tfEfternamn.getText();
                   String namn = "Update anstalld set namn = '" + helanamnet + "' where AID = '" + anvAID + "'";
                   System.out.println(namn);
                   TestAvDB.getIDB().update(namn);
               }
               if(Validering.textNotEmpty2(tfMail) == true)
               {
                   String mail = "Update anstalld set mail = '" + tfMail.getText() + "' where AID = '" + anvAID + "'";
                   System.out.println(mail);
                   TestAvDB.getIDB().update(mail);
               }
               if(Validering.textNotEmpty2(tfTelefon) == true)
               {
                  String telefon = "Update anstalld set telefon = '" + tfTelefon.getText() + "' where AID = '" + anvAID + "'";
                  System.out.println(telefon);
                  TestAvDB.getIDB().update(telefon);
               }

               if(cbAdministratör.isSelected())
               {
                   String nyttLosenord = new BigInteger(130, random).toString(32).substring(0,6);
                   String admin = "Select AID from Administrator where AID = '" + Integer.parseInt(anvAID) + "'";
                   if(!anvAID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(admin)))
                   {
                       String fraga = "INSERT INTO ADMINISTRATOR(AID, LOSENORD) VALUES(" + anvAID + ",'" + nyttLosenord + "')";
                       TestAvDB.getIDB().insert(fraga);
                   }
                   else
                   {
                       adminz = true;
                   }

               }

               if(cbProjektledare.isSelected())
               {
                   String projektledare = "Select AID from projektledare where AID = '" + Integer.parseInt(anvAID) + "'";
                   if(!anvAID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(projektledare)))
                   {
                   String fraga = "Insert into projektledare(AID) values(" + anvAID + ")";
                   TestAvDB.getIDB().insert(fraga);
                   }

                   else
                   {
                       projlead = true;
                   }
               }

               if(cbSpecialist.isSelected())
               {
                   String specialist = "Select AID from specialist where AID = '" + Integer.parseInt(anvAID) + "'";
                   if(!anvAID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(specialist)))
                   {
                   String fraga = "Insert into specialist(AID) values(" + anvAID + ")";
                   TestAvDB.getIDB().insert(fraga);
                   }
                   else
                   {
                       specialistz = true;
                   }
               }

               if(specialistz == true || adminz == true || projlead == true)
               {
                   String special = " specialist";
                   String adman = " administratör";
                   String projlad = " projektledare";
                   String felmessage = "Denna person är redan";
                   registrerad = false;

                   if(specialistz == true)
                   {
                       felmessage += special;
                   }
                   if(adminz == true)
                   {
                       felmessage += adman;
                   }
                   if(projlead == true)
                   {
                       felmessage += projlad;
                   }
                   Validering.felmeddelande(felmessage);
               }
               JOptionPane.showMessageDialog(null, tfNamn.getText() + " " + tfEfternamn.getText() +" har uppdaterats.");
               registrerad = true;
            }
            }
        }
        if(registrerad == true )
        {
            setVisible(false);
        }
       }
       
       catch(InfException error)
       {
           System.out.println(error);
       }
    }//GEN-LAST:event_btnRegistreraMouseClicked

    private void btnTaBortAnstalldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTaBortAnstalldMouseClicked
        //Öppnar fönstret för att sparka en anställd.
        sparka.setVisible(true);
    }//GEN-LAST:event_btnTaBortAnstalldMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UppdateraAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UppdateraAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UppdateraAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UppdateraAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UppdateraAnstalld().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnKompetenser;
    private javax.swing.JButton btnRegistrera;
    private javax.swing.JButton btnTaBortAnstalld;
    private javax.swing.JCheckBox cbAdministratör;
    private javax.swing.JCheckBox cbProjektledare;
    private javax.swing.JCheckBox cbSpecialist;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JTextField tfAID;
    private javax.swing.JTextField tfEfternamn;
    private javax.swing.JTextField tfMail;
    private javax.swing.JTextField tfNamn;
    private javax.swing.JTextField tfTelefon;
    // End of variables declaration//GEN-END:variables
}

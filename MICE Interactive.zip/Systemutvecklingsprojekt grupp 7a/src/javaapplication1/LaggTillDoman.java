
package javaapplication1;

import javax.swing.JOptionPane;
import oru.inf.InfException;


public class LaggTillDoman extends javax.swing.JFrame {

   
    public LaggTillDoman() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfBenamning = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnLaggTillDoman = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnGaTillbaka = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taBeskrivning = new javax.swing.JTextArea();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        tfBenamning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfBenamning);
        tfBenamning.setBounds(40, 60, 220, 30);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Beskrivning");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(40, 90, 100, 30);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Benämning");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 20, 90, 50);

        btnLaggTillDoman.setBackground(new java.awt.Color(153, 204, 255));
        btnLaggTillDoman.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnLaggTillDoman.setText("Lägg Till Domän");
        btnLaggTillDoman.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLaggTillDoman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLaggTillDomanMouseClicked(evt);
            }
        });
        getContentPane().add(btnLaggTillDoman);
        btnLaggTillDoman.setBounds(40, 270, 150, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(490, 40, 130, 30);

        taBeskrivning.setColumns(20);
        taBeskrivning.setRows(5);
        taBeskrivning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(taBeskrivning);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(40, 120, 300, 140);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, -10, 710, 410);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLaggTillDomanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLaggTillDomanMouseClicked
        // En metod som körs när man trycker lägg till domän. Den kontrollerar först informationen och lägger den till den önskade domänen.
        try
        {
            String kollaBenamning = "Select benamning from kompetensdoman where benamning = '" + tfBenamning.getText() + "'";
            if(!Validering.textNotEmpty2(tfBenamning))
            {
                JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma");
            }
            else if(tfBenamning.getText().equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(kollaBenamning)))
            {
                JOptionPane.showMessageDialog(null, "Det finns redan en domän med benämningen: " + tfBenamning.getText());
            }
            else if(!tfBenamning.getText().equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(kollaBenamning)))
            {
               String laggTillDoman = "insert into kompetensdoman(KID,benamning, beskrivning) values('" + TestAvDB.getIDB().getAutoIncrement("kompetensdoman", "kid") + 
                "', '" + tfBenamning.getText() + "', '" + taBeskrivning.getText() + "')";
               TestAvDB.getIDB().insert(laggTillDoman);
               JOptionPane.showMessageDialog(null, "Kompetensdomänen " + tfBenamning.getText() + " har lagts till. Glöm inte att trycka refresh!");
                setVisible(false);
            }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }//GEN-LAST:event_btnLaggTillDomanMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        // Går tillbaka genom att sätta visible till false.
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LaggTillDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LaggTillDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LaggTillDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LaggTillDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LaggTillDoman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnLaggTillDoman;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taBeskrivning;
    private javax.swing.JTextField tfBenamning;
    // End of variables declaration//GEN-END:variables
}

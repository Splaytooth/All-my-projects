package javaapplication1;

import java.util.ArrayList;
import java.util.HashMap;
import oru.inf.InfException;

public class Specialistprojledare extends javax.swing.JFrame {


    public Specialistprojledare() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGaTillbaka = new javax.swing.JButton();
        tfSokruta = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        taSokResultat = new javax.swing.JTextArea();
        btnSokProjektledare = new javax.swing.JButton();
        btnSokSpecialist = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(540, 30, 90, 30);

        tfSokruta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfSokruta);
        tfSokruta.setBounds(40, 70, 220, 30);

        taSokResultat.setEditable(false);
        taSokResultat.setBackground(new java.awt.Color(204, 204, 204));
        taSokResultat.setColumns(20);
        taSokResultat.setRows(5);
        taSokResultat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(taSokResultat);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(40, 100, 470, 190);

        btnSokProjektledare.setBackground(new java.awt.Color(153, 204, 255));
        btnSokProjektledare.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnSokProjektledare.setText("Sök Projektledare");
        btnSokProjektledare.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSokProjektledare.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSokProjektledareMouseClicked(evt);
            }
        });
        getContentPane().add(btnSokProjektledare);
        btnSokProjektledare.setBounds(380, 70, 130, 30);

        btnSokSpecialist.setBackground(new java.awt.Color(153, 204, 255));
        btnSokSpecialist.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnSokSpecialist.setText("Sök Specialist");
        btnSokSpecialist.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSokSpecialist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSokSpecialistMouseClicked(evt);
            }
        });
        getContentPane().add(btnSokSpecialist);
        btnSokSpecialist.setBounds(260, 70, 120, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 640, 370);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    private void btnSokSpecialistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSokSpecialistMouseClicked
        // Söker efter specialist efter diverse inmatningskontroller har gjorts.
        taSokResultat.setText("");
        try
        {
            String anstAID = TestAvDB.getIDB().fetchSingle("select AID from anstalld where lower(namn) = '" + tfSokruta.getText().toLowerCase() + "'");
            String specAID = TestAvDB.getIDB().fetchSingle("select AID from specialist where AID = '" + anstAID + "'");
            if(anstAID.equalsIgnoreCase(specAID))
            {
                String sokFraga = "select SPELPROJEKT.BETECKNING, SPELPROJEKT.STARTDATUM, SPELPROJEKT.RELEASEDATUM from SPELPROJEKT \n" +
                "JOIN ARBETAR_I on ARBETAR_I.SID = SPELPROJEKT.SID\n" +
                "JOIN ANSTALLD on ANSTALLD.AID = ARBETAR_I.AID\n" +
                "where lower(ANSTALLD.NAMN) = '" + tfSokruta.getText().toLowerCase() + "'";
                ArrayList<HashMap<String, String>> rader = TestAvDB.getIDB().fetchRows(sokFraga);
                
                for(HashMap<String, String> rad : rader)
                {
                    String printrad = rad.toString();
                    taSokResultat.append(printrad);
                    taSokResultat.append("\n");
                    taSokResultat.append("\n");
                }
            }
        }
        
        catch(InfException error)
        {
            taSokResultat.setText("Inga sök träffar.\n" + "Skriv in förnamn samt efternamn och se till att det är rätt stavat. \n" + "Exempel: Bo Bullit");
            System.out.println(error);
        }
    }//GEN-LAST:event_btnSokSpecialistMouseClicked

    private void btnSokProjektledareMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSokProjektledareMouseClicked
        // Söker efter projektledare efter diverse inmatningskontroller har gjorts.
        taSokResultat.setText("");
        try
        {
            String aid = TestAvDB.getIDB().fetchSingle("select AID from anstalld where lower(namn) = '" + tfSokruta.getText().toLowerCase() + "'");
            String pid = TestAvDB.getIDB().fetchSingle("select AID from projektledare where AID = '" + aid + "'");
            if(aid.equalsIgnoreCase(pid))
            {
                String sokFraga = "select SPELPROJEKT.BETECKNING, SPELPROJEKT.STARTDATUM, SPELPROJEKT.RELEASEDATUM from SPELPROJEKT\n" +
                "join PROJEKTLEDARE on SPELPROJEKT.AID = PROJEKTLEDARE.AID\n" +
                "join ANSTALLD on ANSTALLD.AID = PROJEKTLEDARE.AID\n" +
                "where lower(ANSTALLD.NAMN) = '" + tfSokruta.getText().toLowerCase() + "'";
                ArrayList<HashMap<String,String>> rader = TestAvDB.getIDB().fetchRows(sokFraga);
                for(HashMap<String, String> rad : rader)
                {
                    String printrad = rad.toString();
                    taSokResultat.append(printrad);
                    taSokResultat.append("\n");
                    taSokResultat.append("\n");
                }
            } 
        }
        catch(InfException error)
        {
            taSokResultat.setText("Inga sök träffar.\n" + "Skriv in förnamn samt efternamn och se till att det är rätt stavat. \n" + "Exempel: Gary Glitter");
            System.out.println(error);
        }
    }//GEN-LAST:event_btnSokProjektledareMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Specialistprojledare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Specialistprojledare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Specialistprojledare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Specialistprojledare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Specialistprojledare().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnSokProjektledare;
    private javax.swing.JButton btnSokSpecialist;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taSokResultat;
    private javax.swing.JTextField tfSokruta;
    // End of variables declaration//GEN-END:variables
}

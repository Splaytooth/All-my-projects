package javaapplication1;

import java.awt.Color;
import javax.swing.JOptionPane;
import oru.inf.InfException;

public class UppdateraProjekt extends javax.swing.JFrame {

    private LaggTillProjAnstalld projanst;
    
    public UppdateraProjekt() {
        //Skapar de fönster som man ska kunna nå från detta fönster.
        initComponents();
        projanst = new LaggTillProjAnstalld();
        projanst.setSize(640,350);
        projanst.setLocation(600, 300);
        if(!tbtnLaggTillPlattform.isSelected())
       {
           tbtnLaggTillPlattform.setText("Ta Bort Plattform");
           tbtnLaggTillPlattform.setBackground(Color.red);
       }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnUtfor = new javax.swing.JButton();
        tfTitel = new javax.swing.JTextField();
        tfStartDatum = new javax.swing.JTextField();
        tfReleaseDatum = new javax.swing.JTextField();
        cbWii = new javax.swing.JCheckBox();
        cbWiiU = new javax.swing.JCheckBox();
        cbNintendoDS = new javax.swing.JCheckBox();
        cbPlayStationPortable = new javax.swing.JCheckBox();
        cbPLayStation3 = new javax.swing.JCheckBox();
        cbXbox = new javax.swing.JCheckBox();
        CBXbox360 = new javax.swing.JCheckBox();
        cbAtari2600 = new javax.swing.JCheckBox();
        cbVectrex = new javax.swing.JCheckBox();
        lblNyTitel = new javax.swing.JLabel();
        lblStartDatum = new javax.swing.JLabel();
        lblReleaseDatum = new javax.swing.JLabel();
        tfVilketProjekt = new javax.swing.JTextField();
        lblGammalTitel = new javax.swing.JLabel();
        tbtnLaggTillPlattform = new javax.swing.JToggleButton();
        btnLaggTillAnstProj = new javax.swing.JButton();
        btnGaTillbaka = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        btnUtfor.setBackground(new java.awt.Color(153, 204, 255));
        btnUtfor.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnUtfor.setText("Utför");
        btnUtfor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnUtfor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUtforMouseClicked(evt);
            }
        });
        getContentPane().add(btnUtfor);
        btnUtfor.setBounds(150, 260, 70, 30);

        tfTitel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfTitel);
        tfTitel.setBounds(150, 100, 210, 30);

        tfStartDatum.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfStartDatum);
        tfStartDatum.setBounds(150, 140, 210, 30);

        tfReleaseDatum.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfReleaseDatum);
        tfReleaseDatum.setBounds(150, 180, 210, 30);

        cbWii.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbWii.setForeground(new java.awt.Color(255, 255, 255));
        cbWii.setText("Wii");
        getContentPane().add(cbWii);
        cbWii.setBounds(400, 60, 110, 23);

        cbWiiU.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbWiiU.setForeground(new java.awt.Color(255, 255, 255));
        cbWiiU.setText("Wii U");
        getContentPane().add(cbWiiU);
        cbWiiU.setBounds(400, 80, 150, 20);

        cbNintendoDS.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbNintendoDS.setForeground(new java.awt.Color(255, 255, 255));
        cbNintendoDS.setText("Nintendo DS");
        getContentPane().add(cbNintendoDS);
        cbNintendoDS.setBounds(400, 100, 150, 23);

        cbPlayStationPortable.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbPlayStationPortable.setForeground(new java.awt.Color(255, 255, 255));
        cbPlayStationPortable.setText("PlayStation Portable");
        getContentPane().add(cbPlayStationPortable);
        cbPlayStationPortable.setBounds(400, 120, 190, 20);

        cbPLayStation3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbPLayStation3.setForeground(new java.awt.Color(255, 255, 255));
        cbPLayStation3.setText("PlayStation 3");
        getContentPane().add(cbPLayStation3);
        cbPLayStation3.setBounds(400, 140, 110, 23);

        cbXbox.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbXbox.setForeground(new java.awt.Color(255, 255, 255));
        cbXbox.setText("XBox");
        getContentPane().add(cbXbox);
        cbXbox.setBounds(400, 160, 120, 23);

        CBXbox360.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        CBXbox360.setForeground(new java.awt.Color(255, 255, 255));
        CBXbox360.setText("XBox 360");
        getContentPane().add(CBXbox360);
        CBXbox360.setBounds(400, 180, 140, 23);

        cbAtari2600.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbAtari2600.setForeground(new java.awt.Color(255, 255, 255));
        cbAtari2600.setText("Atari 2600");
        getContentPane().add(cbAtari2600);
        cbAtari2600.setBounds(400, 200, 110, 23);

        cbVectrex.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbVectrex.setForeground(new java.awt.Color(255, 255, 255));
        cbVectrex.setText("Vectrex");
        getContentPane().add(cbVectrex);
        cbVectrex.setBounds(400, 220, 110, 23);

        lblNyTitel.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblNyTitel.setForeground(new java.awt.Color(255, 255, 255));
        lblNyTitel.setText("Ny titel");
        getContentPane().add(lblNyTitel);
        lblNyTitel.setBounds(80, 110, 60, 20);

        lblStartDatum.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblStartDatum.setForeground(new java.awt.Color(255, 255, 255));
        lblStartDatum.setText("Start Datum");
        getContentPane().add(lblStartDatum);
        lblStartDatum.setBounds(60, 150, 70, 14);

        lblReleaseDatum.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblReleaseDatum.setForeground(new java.awt.Color(255, 255, 255));
        lblReleaseDatum.setText("Release Datum");
        getContentPane().add(lblReleaseDatum);
        lblReleaseDatum.setBounds(50, 190, 90, 14);

        tfVilketProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfVilketProjekt);
        tfVilketProjekt.setBounds(150, 60, 210, 30);

        lblGammalTitel.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblGammalTitel.setForeground(new java.awt.Color(255, 255, 255));
        lblGammalTitel.setText("Gammal titel");
        getContentPane().add(lblGammalTitel);
        lblGammalTitel.setBounds(60, 70, 80, 20);

        tbtnLaggTillPlattform.setBackground(new java.awt.Color(153, 204, 255));
        tbtnLaggTillPlattform.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tbtnLaggTillPlattform.setText("Lägg Till Plattform");
        tbtnLaggTillPlattform.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tbtnLaggTillPlattform.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbtnLaggTillPlattformMouseClicked(evt);
            }
        });
        getContentPane().add(tbtnLaggTillPlattform);
        tbtnLaggTillPlattform.setBounds(400, 260, 130, 30);

        btnLaggTillAnstProj.setBackground(new java.awt.Color(153, 204, 255));
        btnLaggTillAnstProj.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnLaggTillAnstProj.setText("Lägg Till Anställda/Projektledare");
        btnLaggTillAnstProj.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLaggTillAnstProj.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLaggTillAnstProjMouseClicked(evt);
            }
        });
        getContentPane().add(btnLaggTillAnstProj);
        btnLaggTillAnstProj.setBounds(150, 220, 200, 30);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(540, 30, 90, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 340, 960, 20);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 0, 650, 360);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnUtforMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUtforMouseClicked
       //Kontrollerar inmatat information och utför därefter de förändringar man valt till ett specifikt projekt.
        try
        {
        String SID = TestAvDB.getIDB().fetchSingle("select SID from spelprojekt where beteckning = '" + tfVilketProjekt.getText() + "'");
        System.out.println(SID);
        if(!Validering.textNotEmpty2(tfTitel) || !Validering.textNotEmpty2(tfVilketProjekt) || !Validering.textNotEmpty2(tfStartDatum) || !Validering.textNotEmpty2(tfReleaseDatum))
        {
            JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma.");
        }
        else
        {
            if(SID == null )
            {
                JOptionPane.showMessageDialog(null, "Hittade inget projekt med den gamla titeln.");
            }
            else if(!Validering.kontrolleraDatum(tfStartDatum.getText()) || !Validering.kontrolleraDatum(tfReleaseDatum.getText()))
            {
                JOptionPane.showMessageDialog(null, "Fel datum format. Exempel: 12.03.2014 (DD.MM.YYYY)");
            }
            else if(SID != null)
            {
            String vilketProjekt = "select beteckning from spelprojekt where beteckning = '" + tfVilketProjekt.getText() + "'";
            if(tfVilketProjekt.getText().equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(vilketProjekt)))
            {
                String titel = "update spelprojekt set beteckning = '" + tfTitel.getText() + "' where beteckning = '" + tfVilketProjekt.getText() + "'";
                String startDatum = "update spelprojekt set startdatum = '" + tfStartDatum.getText() + "' where beteckning = '" + tfVilketProjekt.getText() + "'";
                String releaseDatum = "update spelprojekt set releasedatum = '" + tfReleaseDatum.getText() + "' where beteckning = '" + tfVilketProjekt.getText() + "'";
                
                TestAvDB.getIDB().update(titel);
                TestAvDB.getIDB().update(startDatum);
                TestAvDB.getIDB().update(releaseDatum); 
                
                
                
                
                if(tbtnLaggTillPlattform.isSelected())
                {
                   
                if(cbWii.isSelected())
                {
                  String wiiID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbWii.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + wiiID + "' and SID = '" + SID + "'";
                  if(!wiiID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String wii = "insert into innefattar(SID,PID) values('" + SID + "', " + wiiID + ")";
                      System.out.println(wii);
                      TestAvDB.getIDB().insert(wii);
                  } 
                }
                if(cbWiiU.isSelected())
                {
                    String wiiUID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbWiiU.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + wiiUID + "' and SID = '" + SID + "'";
                    if(!wiiUID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String wiiU = "insert into innefattar(SID,PID) values('" + SID + "', " + wiiUID + ")";
                      System.out.println(wiiU);
                      TestAvDB.getIDB().insert(wiiU);
                  } 
                    
                }
                if(cbNintendoDS.isSelected())
                {
                    String nintendoDSID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbNintendoDS.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + nintendoDSID + "' and SID = '" + SID + "'";
                    if(!nintendoDSID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String nintendo = "insert into innefattar(SID,PID) values('" + SID + "', " + nintendoDSID + ")";
                      System.out.println(nintendo);
                      TestAvDB.getIDB().insert(nintendo);
                  } 
                }
                if(cbPlayStationPortable.isSelected())
                {
                    String pspID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbPlayStationPortable.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + pspID + "' and SID = '" + SID + "'";
                    if(!pspID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String psp = "insert into innefattar(SID,PID) values(" + SID + ", " + pspID + ")";
                      System.out.println(psp);
                      TestAvDB.getIDB().insert(psp);
                  } 
                    
                }
                if(cbPLayStation3.isSelected())
                {
                    String ps3ID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbPLayStation3.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + ps3ID + "' and SID = '" + SID + "'";
                    if(!ps3ID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String ps3 = "insert into innefattar(SID,PID) values(" + SID + ", " + ps3ID + ")";
                      System.out.println(ps3);
                      TestAvDB.getIDB().insert(ps3);
                  } 
                }
                if(cbXbox.isSelected())
                {
                    String xboxID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbXbox.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + xboxID + "' and SID = '" + SID + "'";
                    if(!xboxID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String xbox = "insert into innefattar(SID,PID) values(" + SID + ", " + xboxID + ")";
                      System.out.println(xbox);
                      TestAvDB.getIDB().insert(xbox);
                  } 
                }
                if(CBXbox360.isSelected())
                {
                    String xbox360ID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + CBXbox360.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + xbox360ID + "' and SID = '" + SID + "'";
                    if(!xbox360ID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String xbox360 = "insert into innefattar(SID,PID) values(" + SID + ", " + xbox360ID + ")";
                      System.out.println(xbox360);
                      TestAvDB.getIDB().insert(xbox360);
                  } 
                }
                if(cbAtari2600.isSelected())
                {
                    String atariID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbAtari2600.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + atariID + "' and SID = '" + SID + "'";
                    if(!atariID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String atari = "insert into innefattar(SID,PID) values(" + SID + ", " + atariID + ")";
                      System.out.println(atari);
                      TestAvDB.getIDB().insert(atari);
                  } 
                }
                if(cbVectrex.isSelected())
                {
                    String vectrexID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbVectrex.getText() + "'");
                    String SQLfraga = "select PID from innefattar where PID = '" + vectrexID + "' and SID = '" + SID + "'";
                    if(!vectrexID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String vectrex = "insert into innefattar(SID,PID) values(" + SID + ", " + vectrexID + ")";
                      System.out.println(vectrex);
                      TestAvDB.getIDB().insert(vectrex);
                  } 
                }
                
              }
                
            }
            
            if(!tbtnLaggTillPlattform.isSelected())
                {
                   
                if(cbWii.isSelected())
                {
                  String wiiID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbWii.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + wiiID + "' and SID = '" + SID + "'";
                  if(wiiID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String wii = "Delete from innefattar where PID = '" + wiiID + "' and SID = '" + SID + "'";
                      System.out.println(wii);
                      TestAvDB.getIDB().delete(wii);
                  } 
                }
                if(cbWiiU.isSelected())
                {
                     String wiiUID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbWiiU.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + wiiUID + "' and SID = '" + SID + "'";
                  if(wiiUID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String wiiU = "Delete from innefattar where PID = '" + wiiUID + "' and SID = '" + SID + "'";
                      System.out.println(wiiU);
                      TestAvDB.getIDB().delete(wiiU);
                  }
                }
                if(cbNintendoDS.isSelected())
                {
                     String nintendoID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbNintendoDS.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + nintendoID + "' and SID = '" + SID + "'";
                  if(nintendoID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String nintendo = "Delete from innefattar where PID = '" + nintendoID + "' and SID = '" + SID + "'";
                      System.out.println(nintendo);
                      TestAvDB.getIDB().delete(nintendo);
                  }
                }
                if(cbPlayStationPortable.isSelected())
                {
                     String pspID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbPlayStationPortable.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + pspID + "' and SID = '" + SID + "'";
                  if(pspID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String psp = "Delete from innefattar where PID = '" + pspID + "' and SID = '" + SID + "'";
                      System.out.println(psp);
                      TestAvDB.getIDB().delete(psp);
                  }
                }
                if(cbPLayStation3.isSelected())
                {
                     String ps3ID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbPLayStation3.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + ps3ID + "' and SID = '" + SID + "'";
                  if(ps3ID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String psp3 = "Delete from innefattar where PID = '" + ps3ID + "' and SID = '" + SID + "'";
                      System.out.println(psp3);
                      TestAvDB.getIDB().delete(psp3);
                  }
                }
                if(cbXbox.isSelected())
                {
                     String xboxID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbXbox.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + xboxID + "' and SID = '" + SID + "'";
                  if(xboxID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String xbox = "Delete from innefattar where PID = '" + xboxID + "' and SID = '" + SID + "'";
                      System.out.println(xbox);
                      TestAvDB.getIDB().delete(xbox);
                  }
                }
                if(CBXbox360.isSelected())
                {
                     String xbox360ID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + CBXbox360.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + xbox360ID + "' and SID = '" + SID + "'";
                  if(xbox360ID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String xbox360 = "Delete from innefattar where PID = '" + xbox360ID + "' and SID = '" + SID + "'";
                      System.out.println(xbox360);
                      TestAvDB.getIDB().delete(xbox360);
                  }
                }
                if(cbAtari2600.isSelected())
                {
                     String atariID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbAtari2600.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + atariID + "' and SID = '" + SID + "'";
                  if(atariID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String atari = "Delete from innefattar where PID = '" + atariID + "' and SID = '" + SID + "'";
                      System.out.println(atari);
                      TestAvDB.getIDB().delete(atari);
                  }
                }
                if(cbVectrex.isSelected())
                {
                     String vectrexID = TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = '" + cbVectrex.getText() + "'");
                  String SQLfraga = "select PID from innefattar where PID = '" + vectrexID + "' and SID = '" + SID + "'";
                  if(vectrexID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(SQLfraga)))
                  {
                      String vectrex = "Delete from innefattar where PID = '" + vectrexID + "' and SID = '" + SID + "'";
                      System.out.println(vectrex);
                      TestAvDB.getIDB().delete(vectrex);
                  }
                }
                
              }
            JOptionPane.showMessageDialog(null, "Projektet " + tfVilketProjekt.getText() + " har uppdaterats.");
            setVisible(false);
        }
        }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }//GEN-LAST:event_btnUtforMouseClicked

    private void tbtnLaggTillPlattformMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbtnLaggTillPlattformMouseClicked
      //Alternerar mellan att lägga till eller ta bort en plattform från ett projekt beroende på om knappen är intryckt eller inte. Utför inte den faktiska ändringen i databasen.
        if(tbtnLaggTillPlattform.isSelected())
      {
          tbtnLaggTillPlattform.setBackground(Color.green);
          tbtnLaggTillPlattform.setText("Lägg Till Plattform");
      }
      if(!tbtnLaggTillPlattform.isSelected())
      {
          tbtnLaggTillPlattform.setBackground(Color.red);
          tbtnLaggTillPlattform.setText("Ta Bort Plattform");
      }
    }//GEN-LAST:event_tbtnLaggTillPlattformMouseClicked

    private void btnLaggTillAnstProjMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLaggTillAnstProjMouseClicked
       //Öppnar fönstret för att lägga till anställda och projektledare i ett projekt.
        projanst.setVisible(true);
    }//GEN-LAST:event_btnLaggTillAnstProjMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        //Stänger det aktuella fönstret.
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UppdateraProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UppdateraProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UppdateraProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UppdateraProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UppdateraProjekt().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox CBXbox360;
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnLaggTillAnstProj;
    private javax.swing.JButton btnUtfor;
    private javax.swing.JCheckBox cbAtari2600;
    private javax.swing.JCheckBox cbNintendoDS;
    private javax.swing.JCheckBox cbPLayStation3;
    private javax.swing.JCheckBox cbPlayStationPortable;
    private javax.swing.JCheckBox cbVectrex;
    private javax.swing.JCheckBox cbWii;
    private javax.swing.JCheckBox cbWiiU;
    private javax.swing.JCheckBox cbXbox;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblGammalTitel;
    private javax.swing.JLabel lblNyTitel;
    private javax.swing.JLabel lblReleaseDatum;
    private javax.swing.JLabel lblStartDatum;
    private javax.swing.JToggleButton tbtnLaggTillPlattform;
    private javax.swing.JTextField tfReleaseDatum;
    private javax.swing.JTextField tfStartDatum;
    private javax.swing.JTextField tfTitel;
    private javax.swing.JTextField tfVilketProjekt;
    // End of variables declaration//GEN-END:variables
}

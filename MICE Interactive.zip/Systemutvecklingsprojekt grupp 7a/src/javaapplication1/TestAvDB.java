//Klassen som hanterar all kontakt med databasklassen ni så snällt gav oss. 
package javaapplication1;
import java.io.File;
import oru.inf.InfDB;
import oru.inf.InfException;
import javax.swing.JOptionPane;
import java.nio.file.*;

public class TestAvDB extends javax.swing.JFrame {
//Fält som sparar InfDB-klassen.
    static private InfDB idb;
    
    public TestAvDB()
    {   
    //Konstruktorn som skapar klassen.
    try{
    //sokvag = directory till databasfilen. Swenglish.
        String sokvag = Paths.get("").toAbsolutePath().toString() + File.separator + "MICEDB.FDB";
        idb = new InfDB(sokvag);
        System.out.println("Funkar");
        
    }
    catch(InfException error)
    {
        JOptionPane.showMessageDialog(null, error.getMessage());
        System.out.println("Fel" + " " + error.getMessage());
    }
   
    }
    
    static public InfDB getIDB()
    {
        //Returnerar databasen vilket möjliggör anrop till dess metoder.
        return idb;
    }   
}

        
        
    
    
    
        

    

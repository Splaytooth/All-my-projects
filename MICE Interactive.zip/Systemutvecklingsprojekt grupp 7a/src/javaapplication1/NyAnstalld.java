
package javaapplication1;
import oru.inf.InfException;
import java.security.SecureRandom;
import java.math.BigInteger;
import javax.swing.JOptionPane;

public class NyAnstalld extends javax.swing.JFrame {
   
   //Skapar en variabel av en klass som ska generera ett godtyckligt lösenord.
   private SecureRandom random = new SecureRandom();
   
    public NyAnstalld() {
        initComponents();
        setLocation(600, 300);
        setShape(null);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        tfNamn = new javax.swing.JTextField();
        tfTelefon = new javax.swing.JTextField();
        tfMail = new javax.swing.JTextField();
        tfEfternamn = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnRegistrera = new javax.swing.JButton();
        btnGaTillbaka = new javax.swing.JButton();
        cbSpecialist = new javax.swing.JCheckBox();
        cbAdministratör = new javax.swing.JCheckBox();
        cbProjektledare = new javax.swing.JCheckBox();
        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bakgrund = new javax.swing.JLabel();

        jButton1.setText("Gå tillbaka");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        tfNamn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfNamn);
        tfNamn.setBounds(90, 70, 130, 30);

        tfTelefon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfTelefon);
        tfTelefon.setBounds(90, 150, 130, 30);

        tfMail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfMail);
        tfMail.setBounds(90, 190, 130, 30);

        tfEfternamn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfEfternamn);
        tfEfternamn.setBounds(90, 110, 130, 30);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Namn");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 80, 60, 14);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Telefon");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 160, 70, 14);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Mail");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(20, 200, 70, 14);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Efternamn");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(20, 120, 70, 14);

        btnRegistrera.setBackground(new java.awt.Color(153, 204, 255));
        btnRegistrera.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnRegistrera.setText("Registrera");
        btnRegistrera.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnRegistrera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistreraMouseClicked(evt);
            }
        });
        getContentPane().add(btnRegistrera);
        btnRegistrera.setBounds(90, 230, 100, 30);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(510, 40, 100, 30);

        cbSpecialist.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbSpecialist.setForeground(new java.awt.Color(255, 255, 255));
        cbSpecialist.setText("Specialist");
        getContentPane().add(cbSpecialist);
        cbSpecialist.setBounds(240, 120, 100, 23);

        cbAdministratör.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbAdministratör.setForeground(new java.awt.Color(255, 255, 255));
        cbAdministratör.setText("Administratör");
        getContentPane().add(cbAdministratör);
        cbAdministratör.setBounds(240, 80, 100, 23);

        cbProjektledare.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbProjektledare.setForeground(new java.awt.Color(255, 255, 255));
        cbProjektledare.setText("Projektledare");
        getContentPane().add(cbProjektledare);
        cbProjektledare.setBounds(240, 160, 100, 23);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 340, 960, 20);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 0, 720, 370);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistreraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistreraMouseClicked
       // Kontrollerar all information som har skrivits in och registrerar sedan den anställd man önskar att lägga till. 
       boolean registrerad = false;
       if(!Validering.textNotEmpty2(tfNamn) || !Validering.textNotEmpty2(tfEfternamn) || !Validering.textNotEmpty2(tfTelefon))
       {
           JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma.");
       }
       if(Validering.textNotEmpty2(tfNamn) && Validering.textNotEmpty2(tfEfternamn) && Validering.kontrolleraEmail(tfMail.getText()))

        try{
            int anvNummer = 0;
            int AID = Integer.parseInt(TestAvDB.getIDB().getAutoIncrement("ANSTALLD", "AID"));
            String fornamn = tfNamn.getText().substring(0,2);
            String efternamn = tfEfternamn.getText().substring(0,1);
            String anvandarNamn = fornamn + efternamn;
            String sokFraga = "SELECT ANVNAMN FROM ANSTALLD";
            
            int i = 0;
            while(i < TestAvDB.getIDB().fetchColumn(sokFraga).size())
            {
              String anvNamn = TestAvDB.getIDB().fetchColumn(sokFraga).get(i);
              
              if(anvNamn.equalsIgnoreCase(anvandarNamn))
              {
                  anvNummer++;
                  anvandarNamn = fornamn + efternamn + anvNummer;
                  i = 0;
              }
              i++;
            }
            if(anvNummer == 0)
            {
                anvandarNamn = fornamn + efternamn;
            }
            
            String SQLfraga = "INSERT INTO ANSTALLD VALUES(" + 
            TestAvDB.getIDB().getAutoIncrement("ANSTALLD", "AID") + ",'" + 
             tfNamn.getText() + " " + tfEfternamn.getText() + "','" 
             + tfTelefon.getText() + "','" + tfMail.getText() + "','"
             + anvandarNamn + "')";
             TestAvDB.getIDB().insert(SQLfraga); 
             registrerad = true;
             kollaCheckBox(AID);
             
        }
        catch(InfException error)
        {
             System.out.println(error);
        }
              
        if(registrerad == true)
        {
        this.setVisible(false);
        }
        
    }//GEN-LAST:event_btnRegistreraMouseClicked
    private void kollaCheckBox(int AID)
    // Instansierar lösenordsvariabeln och tilldelar ett lösenord OM den anställda man önskar lägga till ska vara administratör.
    // Metoden kontrollerar först om checkboxarna har blivit kryssade och kör sedan olika insertfrågor beroende på val av checkbox.
    {
    try{    
        
        System.out.println(AID);
            if(cbAdministratör.isSelected())
        {
            String nyttLosenord = new BigInteger(130, random).toString(32).substring(0,6);
            String SQLfraga = "INSERT INTO ADMINISTRATOR(AID, LOSENORD) VALUES(" + AID + ",'" + nyttLosenord + "')";
            System.out.println(SQLfraga);
            TestAvDB.getIDB().insert(SQLfraga);
                       
        }
        
        if(cbProjektledare.isSelected())
        {
            String SQLfraga = "INSERT INTO PROJEKTLEDARE VALUES(" + AID +")";
            TestAvDB.getIDB().insert(SQLfraga);
        }
        
        if(cbSpecialist.isSelected())
        {
            String SQLfraga = "INSERT INTO SPECIALIST VALUES(" + AID + ")";
            TestAvDB.getIDB().insert(SQLfraga);
        }
        tfEfternamn.setText("");
        tfMail.setText("");
        tfNamn.setText("");
        tfTelefon.setText("");
        
    }
    catch(InfException error)
    {
        System.out.println(error);
    }
    
    }
    
    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        // Går tillbaka.
        this.setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NyAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NyAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NyAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NyAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NyAnstalld().setVisible(true);
            }
        });
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnRegistrera;
    private javax.swing.JCheckBox cbAdministratör;
    private javax.swing.JCheckBox cbProjektledare;
    private javax.swing.JCheckBox cbSpecialist;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField tfEfternamn;
    private javax.swing.JTextField tfMail;
    private javax.swing.JTextField tfNamn;
    private javax.swing.JTextField tfTelefon;
    // End of variables declaration//GEN-END:variables
}

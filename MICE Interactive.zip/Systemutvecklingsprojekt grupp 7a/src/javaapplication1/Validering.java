package javaapplication1;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import oru.inf.InfException;

public class Validering
{
    static public boolean kollaINT(String textfalt)
    {
        //Metod för att kontrollera att det är en integer som skrivits in i ett fält.
        try{
            Integer.parseInt(textfalt);
        }
        catch(NumberFormatException error)
        {
            System.out.println(error);
            return false;
        }
        
        return true;
    }
    
    static public boolean textNotEmpty(JTextField textfield)
    {
        //Metod för att kontrollera att textfältet inte är tom. Kör även en JOptionPane.
        if(textfield.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma!");
            textfield.requestFocus();
            return false;
        }
        return true;
    }
    
        static public boolean textNotEmpty2(JTextField textfield)
    {   //Kontrollerar att ett textfält inte är tomt. Markerar fältet i fråga som det är fel på.
        if(textfield.getText().isEmpty())
        {
            textfield.requestFocus();
            return false;
        }
        return true;
    }
        
    static public void felmeddelande(String meddelande)
    {
        //Metod vi tänkte använda överallt där ett felmeddelande behövs men vi lite halvt har glömt bort. Koden blir inte så mycket kortare i vilket fall som helst.
        JOptionPane.showMessageDialog(null, meddelande);
    }
    
    static public boolean kontrolleraInlogg(String anvNamn2, String losenord)
    {
        //Metod för att kontrollera att lösenord och användarnamn stämmer överens. Inte säkra på om den borde vara här men nu är den det.
       
        try
        {
            String anstAID = TestAvDB.getIDB().fetchSingle("Select AID from anstalld where anvnamn = '" + anvNamn2 + "'");
            String admAID = TestAvDB.getIDB().fetchSingle("Select AID from administrator where AID = '" + anstAID + "'");
            String losen = TestAvDB.getIDB().fetchSingle("Select losenord from administrator where losenord = '" + losenord + "'");
            
            if(admAID.equalsIgnoreCase(anstAID) && losenord.equals(losen))
            {
                return true;
            }   
        }
        
        catch(InfException error)
        {
            System.out.println(error);
        }
        JOptionPane.showMessageDialog(null, "Fel användarnamn eller lösenord!");
        return false;
        
    }
    
    static public boolean kontrolleraEmail(String falt)
    {
        //Reg-ex metod för att kontrollerar att email fylls i med rätt format.
        String email = 
		"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
		+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        
        if(falt.matches(email))
        {
            return true;
        }
        JOptionPane.showMessageDialog(null, "Felaktig e-mail.\n" + "Exempel: Mathias.Hattaka@johanpetersson.com");
        return false;
    }
    
    static public boolean kontrolleraDatum(String Datum)
    {
        //Reg-ex metod för att kontrollera att datum matas in med rätt format. Dock begränsar den inte hur högt dagar eller månad kan gå.
        String date = "^\\d\\d\\.\\d\\d\\.\\d\\d\\d\\d$";
        System.out.println(Datum);
        if(Datum.matches(date))
        {
            return true;
        }
        return false;
    }
 }


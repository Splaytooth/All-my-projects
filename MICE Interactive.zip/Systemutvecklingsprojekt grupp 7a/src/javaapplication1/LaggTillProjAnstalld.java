
package javaapplication1;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;
import oru.inf.InfException;

public class LaggTillProjAnstalld extends javax.swing.JFrame {

    public LaggTillProjAnstalld() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfVilketProjekt = new javax.swing.JTextField();
        tfLaggTillProjektLedare = new javax.swing.JTextField();
        tfLaggTIllAnstalld = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnLaggTillProjektledare = new javax.swing.JButton();
        btnLaggTillAnstalld = new javax.swing.JButton();
        btnGaTillbaka = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblAnvandarnamn = new javax.swing.JLabel();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        tfVilketProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfVilketProjekt);
        tfVilketProjekt.setBounds(140, 120, 140, 30);

        tfLaggTillProjektLedare.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfLaggTillProjektLedare);
        tfLaggTillProjektLedare.setBounds(140, 170, 140, 30);

        tfLaggTIllAnstalld.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfLaggTIllAnstalld);
        tfLaggTIllAnstalld.setBounds(140, 200, 140, 30);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Vilket Projekt");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 120, 100, 30);

        btnLaggTillProjektledare.setBackground(new java.awt.Color(153, 204, 255));
        btnLaggTillProjektledare.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnLaggTillProjektledare.setText("Ändra Projektledare");
        btnLaggTillProjektledare.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLaggTillProjektledare.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLaggTillProjektledareMouseClicked(evt);
            }
        });
        getContentPane().add(btnLaggTillProjektledare);
        btnLaggTillProjektledare.setBounds(320, 170, 170, 30);

        btnLaggTillAnstalld.setBackground(new java.awt.Color(153, 204, 255));
        btnLaggTillAnstalld.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnLaggTillAnstalld.setText("Lägg Till Anställd");
        btnLaggTillAnstalld.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLaggTillAnstalld.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLaggTillAnstalldMouseClicked(evt);
            }
        });
        getContentPane().add(btnLaggTillAnstalld);
        btnLaggTillAnstalld.setBounds(320, 200, 170, 30);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(540, 40, 90, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        lblAnvandarnamn.setBackground(new java.awt.Color(255, 255, 255));
        lblAnvandarnamn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblAnvandarnamn.setForeground(new java.awt.Color(255, 255, 255));
        lblAnvandarnamn.setText("Användarnamn");
        getContentPane().add(lblAnvandarnamn);
        lblAnvandarnamn.setBounds(50, 180, 100, 40);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 0, 640, 370);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLaggTillProjektledareMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLaggTillProjektledareMouseClicked
        // Knapp som lägger till projektledaren som angivits till ett specifikt projekt.
        // Kontrollerar all information innan den körs. T ex att personen som man försöker lägga till är projektledare.
        // ex: att personen faktiskt finns.
        if(!Validering.textNotEmpty2(tfVilketProjekt) || !Validering.textNotEmpty2(tfLaggTillProjektLedare))
        {
            JOptionPane.showMessageDialog(null, "Ett eller flera fält tomma. Försök igen.");
        }
        else
        {
        try{
          String selectSID = TestAvDB.getIDB().fetchSingle("select SID from spelprojekt where beteckning = '" + tfVilketProjekt.getText() + "'");
          String selectAID = TestAvDB.getIDB().fetchSingle("select AID from anstalld where lower(anvnamn) = '" + tfLaggTillProjektLedare.getText() + "'");
          String kollaProjektLedare = TestAvDB.getIDB().fetchSingle("Select AID from projektledare where AID = '" + selectAID + "'");
          System.out.println(kollaProjektLedare);
        if(selectAID == null)
        {
          JOptionPane.showMessageDialog(null, "Hittade inte den valda projektledaren.");
        }  
        else if(selectSID == null)
        {
          JOptionPane.showMessageDialog(null, "Hittade inte det valda projektet.");
        }
          
        else if(kollaProjektLedare.equals(selectAID))
        {
            JOptionPane.showMessageDialog(null, "Personen är redan projektledare på detta projektet.");
        }
        
        else if(kollaProjektLedare== null)
        {
            JOptionPane.showMessageDialog(null, "Hittade inget projekt med denna benämning.");
        }
        else if(selectAID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(kollaProjektLedare)) && selectSID != null && selectAID != null)
        {
            String projektledare = "update spelprojekt set AID = '" + selectAID + "' where SID = '" + selectSID + "'";
            System.out.println(projektledare);
            TestAvDB.getIDB().update(projektledare);
            JOptionPane.showMessageDialog(null, "Projektledare för ''" + tfVilketProjekt.getText() + "'' har lagts till.");
            setVisible(false);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Det finns ingen projektledare med detta AID, försök igen.");
        }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
        }
    }//GEN-LAST:event_btnLaggTillProjektledareMouseClicked

    private void btnLaggTillAnstalldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLaggTillAnstalldMouseClicked
        //Lägger till en person på projektet efter kontroll at den inte redan är på projektet och att projektet finns.
        if(!Validering.textNotEmpty2(tfVilketProjekt) || !Validering.textNotEmpty2(tfLaggTIllAnstalld))
        {
            JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma.");
        }
        else
        {
        try{
        String selectAID = TestAvDB.getIDB().fetchSingle("select AID from anstalld where anvnamn = '" + tfLaggTIllAnstalld.getText() + "'");
        String selectSID = TestAvDB.getIDB().fetchSingle("select SID from spelprojekt where beteckning = '" + tfVilketProjekt.getText() + "'");
        String kollaArbetarI = "select AID from arbetar_i where AID = '" + selectAID + "' and SID = '" + selectSID + "'";
        
        if(selectSID == null)
        {
            JOptionPane.showMessageDialog(null, "Hittade inget projekt med denna benämning.");
        }
        else if(selectAID == null)
        {
           JOptionPane.showMessageDialog(null, "Hittade ingen anställd med det användarnamnet.");
        }
        else if(selectAID.equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(kollaArbetarI)))
        {
            JOptionPane.showMessageDialog(null, "Denna anställd arbetar redan på detta projekt");
        }
        else
        {
            String anstalld = "insert into arbetar_i(AID,SID) values('" + selectAID + "', '" +  selectSID + "')";
            TestAvDB.getIDB().insert(anstalld);
            String anstNamn = TestAvDB.getIDB().fetchSingle("select namn from anstalld where AID = '" + selectAID + "'");
            JOptionPane.showMessageDialog(null, anstNamn + " har lagts till i " + tfVilketProjekt.getText());
        }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
        }
    }//GEN-LAST:event_btnLaggTillAnstalldMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        //Stänger fönstret.
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LaggTillProjAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LaggTillProjAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LaggTillProjAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LaggTillProjAnstalld.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LaggTillProjAnstalld().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnLaggTillAnstalld;
    private javax.swing.JButton btnLaggTillProjektledare;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblAnvandarnamn;
    private javax.swing.JTextField tfLaggTIllAnstalld;
    private javax.swing.JTextField tfLaggTillProjektLedare;
    private javax.swing.JTextField tfVilketProjekt;
    // End of variables declaration//GEN-END:variables
}


package javaapplication1;
import java.util.*;
import oru.inf.InfException;


public class Kompetensdoman extends javax.swing.JFrame {

    private LaggTillDoman doman;
    private UppdateraDoman uppdoman;
    public Kompetensdoman() {
        initComponents();
        //Instansierar alla fönster som kan öppnas samt "reset:ar" sökfältet.
        setTAtext();
        doman = new LaggTillDoman();
        doman.setSize(640,355);
        doman.setLocation(600,300);
        
        uppdoman = new UppdateraDoman();
        uppdoman.setSize(640,355);
        uppdoman.setLocation(600, 300);
    }

    
    private void setTAtext()
    {
        //Fyller sökresultats-rutan med delvis information om kompetensdomän när den anropas.
        taSokResultat.setText("");
        try
        {
        ArrayList<HashMap<String,String>> rader = TestAvDB.getIDB().fetchRows("select kid, benamning from kompetensdoman");
        for(HashMap<String,String> rad:rader)
        {
            String printrad = rad.toString();
            taSokResultat.append(printrad);
            taSokResultat.append("\n");
            taSokResultat.append("\n");
        }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }
    
    private void setTAtext2()
    {
        //Fyller sökresultatet med ytterliggare information när den anropas, dvs beskrivning och benämning.
        taSokResultat.setText("");
        try
        {
        ArrayList<HashMap<String,String>> rader = TestAvDB.getIDB().fetchRows("select beskrivning, benamning from kompetensdoman");
        for(HashMap<String,String> rad:rader)
        {
            String printrad = rad.toString();
            taSokResultat.append(printrad);
            taSokResultat.append("\n");
            taSokResultat.append("\n");
        }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        taSokResultat = new javax.swing.JTextArea();
        btnUppdateraDoman = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnLaggTillDoman = new javax.swing.JButton();
        btnVisaBeskrivning = new javax.swing.JButton();
        btnVisaDomaner = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnGaTillbaka = new javax.swing.JButton();
        Bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        taSokResultat.setEditable(false);
        taSokResultat.setBackground(new java.awt.Color(204, 204, 204));
        taSokResultat.setColumns(20);
        taSokResultat.setRows(5);
        taSokResultat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane1.setViewportView(taSokResultat);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(20, 80, 490, 190);

        btnUppdateraDoman.setBackground(new java.awt.Color(153, 204, 255));
        btnUppdateraDoman.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnUppdateraDoman.setText("Uppdatera Domän");
        btnUppdateraDoman.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnUppdateraDoman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUppdateraDomanMouseClicked(evt);
            }
        });
        getContentPane().add(btnUppdateraDoman);
        btnUppdateraDoman.setBounds(150, 280, 150, 30);

        btnRefresh.setBackground(new java.awt.Color(153, 204, 255));
        btnRefresh.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnRefresh.setText("Refresh");
        btnRefresh.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnRefresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRefreshMouseClicked(evt);
            }
        });
        getContentPane().add(btnRefresh);
        btnRefresh.setBounds(20, 40, 110, 30);

        btnLaggTillDoman.setBackground(new java.awt.Color(153, 204, 255));
        btnLaggTillDoman.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnLaggTillDoman.setText("Lägg Till Domän");
        btnLaggTillDoman.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnLaggTillDoman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLaggTillDomanMouseClicked(evt);
            }
        });
        getContentPane().add(btnLaggTillDoman);
        btnLaggTillDoman.setBounds(20, 280, 130, 30);

        btnVisaBeskrivning.setBackground(new java.awt.Color(153, 204, 255));
        btnVisaBeskrivning.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnVisaBeskrivning.setText("Visa beskrivning");
        btnVisaBeskrivning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnVisaBeskrivning.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVisaBeskrivningMouseClicked(evt);
            }
        });
        getContentPane().add(btnVisaBeskrivning);
        btnVisaBeskrivning.setBounds(130, 40, 140, 30);

        btnVisaDomaner.setBackground(new java.awt.Color(153, 204, 255));
        btnVisaDomaner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnVisaDomaner.setText("Visa Domäner");
        btnVisaDomaner.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnVisaDomaner.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVisaDomanerMouseClicked(evt);
            }
        });
        getContentPane().add(btnVisaDomaner);
        btnVisaDomaner.setBounds(270, 40, 130, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(460, 40, 110, 30);

        Bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(Bakgrund);
        Bakgrund.setBounds(0, 0, 690, 380);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRefreshMouseClicked
        // Refreshar sökrutan när refresh-knappen trycks. Används om man har nyligen lagt till något och det dyker inte upp.
        setTAtext();
    }//GEN-LAST:event_btnRefreshMouseClicked

    private void btnVisaBeskrivningMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVisaBeskrivningMouseClicked
        // Anropar metoden setTAtext2 och fyller sökrutan med information som beskriver en kompetensdomän.
        setTAtext2();
    }//GEN-LAST:event_btnVisaBeskrivningMouseClicked

    private void btnVisaDomanerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVisaDomanerMouseClicked
        // Anropar metoden setTAtext som fyller sökrutan med information om vilka kompetensdomäner som finns
        setTAtext();
    }//GEN-LAST:event_btnVisaDomanerMouseClicked

    private void btnLaggTillDomanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLaggTillDomanMouseClicked
        // Öppnar fönstret där man kan lägga till domäner.
        doman.setVisible(true);
    }//GEN-LAST:event_btnLaggTillDomanMouseClicked

    private void btnUppdateraDomanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUppdateraDomanMouseClicked
        // Öppnar fönstret där man kan uppdatera domäner.
        uppdoman.setVisible(true);
    }//GEN-LAST:event_btnUppdateraDomanMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        // Går tillbaka genom att sätta visible till false.
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Kompetensdoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Kompetensdoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Kompetensdoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Kompetensdoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Kompetensdoman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnLaggTillDoman;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnUppdateraDoman;
    private javax.swing.JButton btnVisaBeskrivning;
    private javax.swing.JButton btnVisaDomaner;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taSokResultat;
    // End of variables declaration//GEN-END:variables
}

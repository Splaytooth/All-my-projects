//Klass för att hantera anställdas information, lägga till nya anställda och uppdatera befintliga anställda.
package javaapplication1;

import oru.inf.InfException;
import java.util.*;

public class Anstallda extends javax.swing.JFrame {

   private NyAnstalld registrera;
   
   private UppdateraAnstalld uppdatera;
    public Anstallda() {
        initComponents();
        setLocation(600, 300);
        setSize(640, 350);
        
        registrera = new NyAnstalld();
        registrera.setLocation(600, 300);
        registrera.setSize(640, 350);
        
        uppdatera = new UppdateraAnstalld();
        uppdatera.setLocation(600, 300);
        uppdatera.setSize(640, 350);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        Minimera = new javax.swing.JLabel();
        tfSök = new javax.swing.JButton();
        tfSökruta = new javax.swing.JTextField();
        btnGaTillbaka = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        taSokResultat = new javax.swing.JTextArea();
        jComboBox1 = new javax.swing.JComboBox();
        btUppdateraAnstalld = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnLaggTillNyAnstalld = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        Bakgrund = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        Minimera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MinimeraMouseClicked(evt);
            }
        });
        getContentPane().add(Minimera);
        Minimera.setBounds(627, 4, 10, 10);

        tfSök.setBackground(new java.awt.Color(153, 204, 255));
        tfSök.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tfSök.setText("Sök");
        tfSök.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        tfSök.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tfSökMouseClicked(evt);
            }
        });
        getContentPane().add(tfSök);
        tfSök.setBounds(440, 70, 80, 30);

        tfSökruta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(tfSökruta);
        tfSökruta.setBounds(180, 70, 260, 30);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(500, 30, 130, 30);

        taSokResultat.setEditable(false);
        taSokResultat.setBackground(new java.awt.Color(204, 204, 255));
        taSokResultat.setColumns(20);
        taSokResultat.setRows(5);
        taSokResultat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane2.setViewportView(taSokResultat);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(50, 100, 470, 150);

        jComboBox1.setBackground(new java.awt.Color(102, 204, 255));
        jComboBox1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Anställds Kompetens", "Sök Kompetens", "Plattform", "Anställds Projekt", "Anställd Info" }));
        jComboBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(50, 70, 130, 30);

        btUppdateraAnstalld.setBackground(new java.awt.Color(153, 204, 255));
        btUppdateraAnstalld.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btUppdateraAnstalld.setText("Uppdatera anställd");
        btUppdateraAnstalld.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btUppdateraAnstalld.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btUppdateraAnstalldMouseClicked(evt);
            }
        });
        getContentPane().add(btUppdateraAnstalld);
        btUppdateraAnstalld.setBounds(210, 250, 160, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        btnLaggTillNyAnstalld.setBackground(new java.awt.Color(153, 204, 255));
        btnLaggTillNyAnstalld.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnLaggTillNyAnstalld.setText("Lägg till ny anställd");
        btnLaggTillNyAnstalld.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnLaggTillNyAnstalld.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLaggTillNyAnstalldMouseClicked(evt);
            }
        });
        getContentPane().add(btnLaggTillNyAnstalld);
        btnLaggTillNyAnstalld.setBounds(50, 250, 160, 30);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(0, 340, 960, 20);

        Bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(Bakgrund);
        Bakgrund.setBounds(0, 0, 810, 360);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfSökMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfSökMouseClicked
    //Hämtar information beroende på vilken combobox som är vald vid söktillfället.
    //Alla combobox items har inte samma sökord. Ex: Plattform vill ha namn på en plattform. AnstalldInfo vill ha ett namn.
    
        taSokResultat.setText("");
        if(Validering.textNotEmpty2(tfSökruta) == false)
        {
            Validering.felmeddelande("Fyll i fältet, tack.");
        }
        else 
        {
            try
            {
                
                String sokning = tfSökruta.getText();
                String fraga = "select ANSTALLD.NAMN, ANSTALLD.AID, KOMPETENSDOMAN.BENAMNING AS KOMPETENS, PLATTFORM.BENAMNING AS PLATTFORM, "
                               + "HAR_KOMPETENS.KOMPETENSNIVA from ANSTALLD join HAR_KOMPETENS "
                               + "on ANSTALLD.AID = HAR_KOMPETENS.AID"
                               + " join PLATTFORM on PLATTFORM.PID = HAR_KOMPETENS.PID"
                               + " join KOMPETENSDOMAN on KOMPETENSDOMAN.KID = HAR_KOMPETENS.KID where ";

                if(jComboBox1.getSelectedItem().equals("Anställds Kompetens"))
                {
                    fraga += "lower(anstalld.namn) like '%" + sokning.toLowerCase() + "%'";
                }

                if(jComboBox1.getSelectedItem().equals("Sök Kompetens"))
                {
                    fraga += "lower(KOMPETENSDOMAN.BENAMNING) like '%" + sokning.toLowerCase() + "%'";
                }

                if(jComboBox1.getSelectedItem().equals("Plattform"))
                {
                    fraga += "lower(PLATTFORM.BENAMNING) like '%" + sokning.toLowerCase() + "%'";
                }
                
                if (jComboBox1.getSelectedItem().equals("Anställds Projekt")) 
                {   
                    ArrayList<HashMap<String, String>> rader = TestAvDB.getIDB().fetchRows("select ANSTALLD.NAMN, SPELPROJEKT.BETECKNING, SPELPROJEKT.STARTDATUM, SPELPROJEKT.RELEASEDATUM from ANSTALLD \n" +
                    "join ARBETAR_I on ARBETAR_I.AID = ANSTALLD.AID \n" +
                    "join SPELPROJEKT on SPELPROJEKT.SID = ARBETAR_I.SID\n" +
                    "where lower(ANSTALLD.NAMN) like '%" + tfSökruta.getText().toLowerCase() + "%'");
                    if(rader != null)
                    {
                        for(HashMap rad: rader)
                        {
                            String printrad = rad.toString();
                            taSokResultat.append(printrad);
                            taSokResultat.append("\n");
                            taSokResultat.append("\n");
                        }
                    }
                    else
                    {
                        taSokResultat.setText("Inget sökresultat.");
                    }
                }
                
                if(jComboBox1.getSelectedItem().equals("Anställd Info"))
                {
                    
                    ArrayList<HashMap<String,String>> rader = TestAvDB.getIDB().fetchRows("Select * from anstalld where lower(namn) like '%" + tfSökruta.getText().toLowerCase() + "%'");
                    if(rader != null)
                    {
                        for(HashMap<String,String> rad: rader)
                        {
                            String printrad = rad.toString();
                            taSokResultat.append(printrad);
                            taSokResultat.append("\n");
                            taSokResultat.append("\n");
                        }
                    }
                    else
                    {
                        taSokResultat.setText("Inget sökresultat.");
                    }
                }
                
                if(!jComboBox1.getSelectedItem().equals("Anställd info") && !jComboBox1.getSelectedItem().equals("Anställds Projekt"))
                {
                    ArrayList<HashMap<String, String>> svar = TestAvDB.getIDB().fetchRows(fraga);
                    if(svar != null)
                    for(HashMap<String, String> rad : svar) 
                    {
                            String printrad = rad.toString();
                            taSokResultat.append(printrad);
                            taSokResultat.append("\n");
                            taSokResultat.append("\n");
                    }
                    else
                    {
                            taSokResultat.setText("Inget sökresultat.");
                    }
                }
                    
            }
       
            catch(InfException error)
            {
            System.out.println(error);
            }
        }
    }//GEN-LAST:event_tfSökMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
       //Stänger fönstret.
        this.setVisible(false);
       
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    private void btUppdateraAnstalldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btUppdateraAnstalldMouseClicked
        //Öppnar rutan uppdatera.
        uppdatera.setVisible(true);
    }//GEN-LAST:event_btUppdateraAnstalldMouseClicked

    private void MinimeraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinimeraMouseClicked
        //Minimerar fönstret.
        this.setState(HUB.ICONIFIED);
    }//GEN-LAST:event_MinimeraMouseClicked

    private void btnLaggTillNyAnstalldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLaggTillNyAnstalldMouseClicked
        //Öppnar fönstret registrera.
        registrera.setVisible(true);
    }//GEN-LAST:event_btnLaggTillNyAnstalldMouseClicked

 
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Anstallda().setVisible(true);
            }
        });
    }
    
        

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bakgrund;
    private javax.swing.JLabel Minimera;
    private javax.swing.JButton btUppdateraAnstalld;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnLaggTillNyAnstalld;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea taSokResultat;
    private javax.swing.JButton tfSök;
    private javax.swing.JTextField tfSökruta;
    // End of variables declaration//GEN-END:variables
}

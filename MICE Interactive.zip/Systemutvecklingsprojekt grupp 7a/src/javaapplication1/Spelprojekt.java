
package javaapplication1;
import java.util.*;
import oru.inf.InfException;

public class Spelprojekt extends javax.swing.JFrame {

    private NyttProjekt nyprojekt;
    private UppdateraProjekt nyUppdateraProjekt;
   
    
    public Spelprojekt() {
        // Instansierar alla fönster som kan öppnas i detta fönster.
        initComponents();
        nyprojekt = new NyttProjekt();
        nyprojekt.setSize(640, 350);
        nyprojekt.setLocation(600, 300);
        
        nyUppdateraProjekt = new UppdateraProjekt();
        nyUppdateraProjekt.setSize(640,350);
        nyUppdateraProjekt.setLocation(600,300);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNyttProjekt = new javax.swing.JButton();
        btnUppdateraProjekt = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taSokRuta = new javax.swing.JTextArea();
        tfSokProjekt = new javax.swing.JTextField();
        btnSokProjekt = new javax.swing.JButton();
        btnVisaPlattformer = new javax.swing.JButton();
        btnVisaAktuellaProjekt = new javax.swing.JButton();
        btnVisaForegaendeProjekt = new javax.swing.JButton();
        btnGaTillbaka = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(640, 355));
        getContentPane().setLayout(null);

        btnNyttProjekt.setBackground(new java.awt.Color(153, 204, 255));
        btnNyttProjekt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnNyttProjekt.setText("Nytt Projekt");
        btnNyttProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnNyttProjekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnNyttProjektMouseClicked(evt);
            }
        });
        getContentPane().add(btnNyttProjekt);
        btnNyttProjekt.setBounds(30, 270, 130, 31);

        btnUppdateraProjekt.setBackground(new java.awt.Color(153, 204, 255));
        btnUppdateraProjekt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnUppdateraProjekt.setText("Uppdatera Projekt");
        btnUppdateraProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnUppdateraProjekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUppdateraProjektMouseClicked(evt);
            }
        });
        getContentPane().add(btnUppdateraProjekt);
        btnUppdateraProjekt.setBounds(160, 270, 131, 32);

        taSokRuta.setEditable(false);
        taSokRuta.setBackground(new java.awt.Color(204, 204, 204));
        taSokRuta.setColumns(20);
        taSokRuta.setRows(5);
        taSokRuta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(taSokRuta);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 70, 460, 200);

        tfSokProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfSokProjekt);
        tfSokProjekt.setBounds(30, 40, 230, 30);

        btnSokProjekt.setBackground(new java.awt.Color(153, 204, 255));
        btnSokProjekt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnSokProjekt.setText("Sök Projekt");
        btnSokProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSokProjekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSokProjektMouseClicked(evt);
            }
        });
        getContentPane().add(btnSokProjekt);
        btnSokProjekt.setBounds(260, 40, 100, 30);

        btnVisaPlattformer.setBackground(new java.awt.Color(153, 204, 255));
        btnVisaPlattformer.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnVisaPlattformer.setText("Visa Plattformer");
        btnVisaPlattformer.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnVisaPlattformer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVisaPlattformerMouseClicked(evt);
            }
        });
        getContentPane().add(btnVisaPlattformer);
        btnVisaPlattformer.setBounds(360, 40, 130, 30);

        btnVisaAktuellaProjekt.setBackground(new java.awt.Color(153, 204, 255));
        btnVisaAktuellaProjekt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnVisaAktuellaProjekt.setText("Visa Aktuella Projekt");
        btnVisaAktuellaProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnVisaAktuellaProjekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVisaAktuellaProjektMouseClicked(evt);
            }
        });
        getContentPane().add(btnVisaAktuellaProjekt);
        btnVisaAktuellaProjekt.setBounds(490, 190, 130, 40);

        btnVisaForegaendeProjekt.setBackground(new java.awt.Color(153, 204, 255));
        btnVisaForegaendeProjekt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnVisaForegaendeProjekt.setText("Visa Färdiga Projekt");
        btnVisaForegaendeProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnVisaForegaendeProjekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVisaForegaendeProjektMouseClicked(evt);
            }
        });
        getContentPane().add(btnVisaForegaendeProjekt);
        btnVisaForegaendeProjekt.setBounds(490, 230, 130, 40);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(520, 40, 100, 30);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 20, 720, 350);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSokProjektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSokProjektMouseClicked
        // Söker projekt efter diverse inmatningskontroller har gjorts.
        taSokRuta.setText("");
        try
        {
            String SQLfraga = "select SPELPROJEKT.BETECKNING, SPELPROJEKT.STARTDATUM, \n" +
                         "SPELPROJEKT.RELEASEDATUM, ANSTALLD.NAMN as PROJEKTLEDARE \n" +
                         "from ANSTALLD join SPELPROJEKT on ANSTALLD.AID = SPELPROJEKT.AID\n" +
                         "where lower(SPELPROJEKT.BETECKNING) like '%" + tfSokProjekt.getText().toLowerCase() + "%'";
            ArrayList<HashMap<String,String>> rows = TestAvDB.getIDB().fetchRows(SQLfraga);
            if(rows != null)
            for(HashMap<String,String> rad: rows)
            {
               String stringTabellRader = rad.toString();

               taSokRuta.append(stringTabellRader);
               taSokRuta.append("\n");
               taSokRuta.append("\n");
            }
            else
            {
                taSokRuta.setText("Ingen sökträff");
            }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }//GEN-LAST:event_btnSokProjektMouseClicked

    private void btnNyttProjektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnNyttProjektMouseClicked
        // Öppnar fönstret för att lägga till nytt projekt.
        nyprojekt.setVisible(true);
    }//GEN-LAST:event_btnNyttProjektMouseClicked

    private void btnUppdateraProjektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUppdateraProjektMouseClicked
        // Öppnar uppdateringsfönstret.
        nyUppdateraProjekt.setVisible(true);
    }//GEN-LAST:event_btnUppdateraProjektMouseClicked

    private void btnVisaPlattformerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVisaPlattformerMouseClicked
        // Fyller sökrutan med information om alla plattformer som finns i ett visst projekt. 
        taSokRuta.setText("");
        String SQLfraga = "select SPELPROJEKT.BETECKNING, PLATTFORM.BENAMNING\n" +
                          "from SPELPROJEKT join INNEFATTAR\n" +
                          "on SPELPROJEKT.SID = INNEFATTAR.SID\n" +
                          "join PLATTFORM on INNEFATTAR.PID = PLATTFORM.PID\n" +
                          "where lower(SPELPROJEKT.BETECKNING) LIKE '%" + tfSokProjekt.getText()+ "%'";
        try
        {
            ArrayList<HashMap<String, String>> spelprojektRader = TestAvDB.getIDB().fetchRows(SQLfraga);
            if(spelprojektRader != null)
            {
                for(HashMap<String, String> projektRad: spelprojektRader)
                {
                    String rad = projektRad.toString();
                    taSokRuta.append(rad);
                    taSokRuta.append("\n");
                    taSokRuta.append("\n");
                }
            }
            else
            {
                taSokRuta.setText("Ingen sökträff");
            }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
        
    }//GEN-LAST:event_btnVisaPlattformerMouseClicked

    private void btnVisaAktuellaProjektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVisaAktuellaProjektMouseClicked
        // Fyller sökrutan med projekt som är under utveckling.
        taSokRuta.setText("");
        try
        {
            ArrayList<HashMap<String, String>> rader = TestAvDB.getIDB().fetchRows("select SPELPROJEKT.BETECKNING, ANSTALLD.NAMN as PROJEKTLEDARE, \n" +
            "SPELPROJEKT.STARTDATUM, SPELPROJEKT.RELEASEDATUM \n" +
            "from SPELPROJEKT join ANSTALLD on SPELPROJEKT.AID = ANSTALLD.AID\n" +
            "where SPELPROJEKT.RELEASEDATUM > CURRENT_DATE and SPELPROJEKT.STARTDATUM < CURRENT_DATE");
            if(rader != null)
            {
               for(HashMap<String, String> rad: rader)
               {
                   String printrad = rad.toString();
                   taSokRuta.append(printrad);
                   taSokRuta.append("\n");
                   taSokRuta.append("\n");
               }
            }
            else
            {
                taSokRuta.setText("Ingen sökträff");
            }
          
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }//GEN-LAST:event_btnVisaAktuellaProjektMouseClicked

    private void btnVisaForegaendeProjektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVisaForegaendeProjektMouseClicked
        // Fyller sökrutan med projekt som är färdiga.
        taSokRuta.setText("");
        try
        {
            ArrayList<HashMap<String, String>> rader = TestAvDB.getIDB().fetchRows("select SPELPROJEKT.BETECKNING, ANSTALLD.NAMN as PROJEKTLEDARE, \n" +
            "SPELPROJEKT.STARTDATUM, SPELPROJEKT.RELEASEDATUM \n" +
            "from SPELPROJEKT join ANSTALLD on SPELPROJEKT.AID = ANSTALLD.AID\n" +
            "where SPELPROJEKT.RELEASEDATUM < CURRENT_DATE");
            if(rader != null)
            {
                for(HashMap<String, String> rad: rader)
                {
                    String printrad = rad.toString();
                    taSokRuta.append(printrad);
                    taSokRuta.append("\n");
                    taSokRuta.append("\n");
                }
            }
            else
            {
                taSokRuta.setText("Ingen sökträff");
            }
        }
        catch(InfException error)
        {
            System.out.println(error);
        }     
    }//GEN-LAST:event_btnVisaForegaendeProjektMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        // Går tillbaka genom att sätta visible till false.
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Spelprojekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Spelprojekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Spelprojekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Spelprojekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Spelprojekt().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnNyttProjekt;
    private javax.swing.JButton btnSokProjekt;
    private javax.swing.JButton btnUppdateraProjekt;
    private javax.swing.JButton btnVisaAktuellaProjekt;
    private javax.swing.JButton btnVisaForegaendeProjekt;
    private javax.swing.JButton btnVisaPlattformer;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taSokRuta;
    private javax.swing.JTextField tfSokProjekt;
    // End of variables declaration//GEN-END:variables
}

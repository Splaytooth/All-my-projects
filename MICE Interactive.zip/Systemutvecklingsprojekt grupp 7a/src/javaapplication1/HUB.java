
package javaapplication1;


public class HUB extends javax.swing.JFrame {

   private Anstallda anstalldaRuta;
   private Inloggning nyInlogg;
   private Spelprojekt spelproj;
   private Kompetensdoman kompetensRuta;
   private Specialistprojledare specproj;
   
   private int xM;
   private int yM;
    public HUB() {
        //Instansierar alla fönster huben kan öppna enligt 'Game of Zuul-principen'. Ni fattar.
        //Sätter även storlek och position på alla fönster. Vilket borde vara i respektive konstruktor nu när vi tänker efter men klockan är mycket och det är Tisdag.
        initComponents();
        anstalldaRuta = new Anstallda();
        anstalldaRuta.setLocation(600, 300);
        anstalldaRuta.setSize(640, 350);
        
        setLocation(600, 300);
        setSize(640,355);
        
        spelproj = new Spelprojekt();
        spelproj.setLocation(600, 300);
        spelproj.setSize(640, 350);
        
        kompetensRuta = new Kompetensdoman();
        kompetensRuta.setLocation(600, 300);
        kompetensRuta.setSize(640, 350);
        
        specproj = new Specialistprojledare();
        specproj.setLocation(600, 300);
        specproj.setSize(640,350);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSpelprojekt = new javax.swing.JButton();
        btnAnstallda = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnLoggaUt = new javax.swing.JButton();
        btnKompetensdoman = new javax.swing.JButton();
        Minimera = new javax.swing.JLabel();
        Stäng = new javax.swing.JLabel();
        drag = new javax.swing.JLabel();
        btnvisualbuttons = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        Bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(640, 360, 640, 360));
        setUndecorated(true);
        getContentPane().setLayout(null);

        btnSpelprojekt.setBackground(new java.awt.Color(153, 204, 255));
        btnSpelprojekt.setFont(new java.awt.Font("FrankRuehl", 1, 14)); // NOI18N
        btnSpelprojekt.setText("Spelprojekt");
        btnSpelprojekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnSpelprojekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSpelprojektMouseClicked(evt);
            }
        });
        getContentPane().add(btnSpelprojekt);
        btnSpelprojekt.setBounds(30, 190, 100, 30);

        btnAnstallda.setBackground(new java.awt.Color(153, 204, 255));
        btnAnstallda.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnAnstallda.setText("Anställda");
        btnAnstallda.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnAnstallda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAnstalldaMouseClicked(evt);
            }
        });
        getContentPane().add(btnAnstallda);
        btnAnstallda.setBounds(30, 150, 100, 30);

        jButton1.setBackground(new java.awt.Color(153, 204, 255));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("Specialist & Projektledare");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(30, 270, 190, 30);

        btnLoggaUt.setBackground(new java.awt.Color(153, 153, 255));
        btnLoggaUt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnLoggaUt.setText("Logga ut");
        btnLoggaUt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnLoggaUt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLoggaUtMouseClicked(evt);
            }
        });
        getContentPane().add(btnLoggaUt);
        btnLoggaUt.setBounds(510, 40, 103, 30);

        btnKompetensdoman.setBackground(new java.awt.Color(153, 204, 255));
        btnKompetensdoman.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnKompetensdoman.setText("Kompetensdomän");
        btnKompetensdoman.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnKompetensdoman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnKompetensdomanMouseClicked(evt);
            }
        });
        getContentPane().add(btnKompetensdoman);
        btnKompetensdoman.setBounds(30, 230, 160, 30);

        Minimera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MinimeraMouseClicked(evt);
            }
        });
        getContentPane().add(Minimera);
        Minimera.setBounds(597, 4, 10, 10);

        Stäng.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                StängMouseClicked(evt);
            }
        });
        getContentPane().add(Stäng);
        Stäng.setBounds(616, 4, 10, 10);

        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(0, 0, 640, 20);

        btnvisualbuttons.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/Buttons.gif"))); // NOI18N
        btnvisualbuttons.setText("jLabel1");
        getContentPane().add(btnvisualbuttons);
        btnvisualbuttons.setBounds(0, 0, 640, 360);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 336, 960, 20);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        Bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(Bakgrund);
        Bakgrund.setBounds(0, 0, 810, 360);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAnstalldaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAnstalldaMouseClicked
        //Öppnar rutan för att hantera Anställda.
        anstalldaRuta.setVisible(true);
    }//GEN-LAST:event_btnAnstalldaMouseClicked

    private void btnLoggaUtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLoggaUtMouseClicked
      //Loggar ut från systemet och visar inloggningsrutan.
        this.setVisible(false);
      nyInlogg = new Inloggning();
      nyInlogg.setVisible(true);
    }//GEN-LAST:event_btnLoggaUtMouseClicked

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        //Möjliggör att man kan flytta på rutan. Håller musen på plats då rutan flyttas.
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xM, y - yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
       //Tillhör DragMouseDragged.
        xM = evt.getX();
       yM = evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void MinimeraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinimeraMouseClicked
       //Minimerar rutan.
        this.setState(HUB.ICONIFIED);
    }//GEN-LAST:event_MinimeraMouseClicked

    private void StängMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_StängMouseClicked
      //Stänger programmet.
        System.exit(0);
    }//GEN-LAST:event_StängMouseClicked

    private void btnSpelprojektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSpelprojektMouseClicked
      //Öppnar fönstret spelprojekt.
        spelproj.setVisible(true);
    }//GEN-LAST:event_btnSpelprojektMouseClicked

    private void btnKompetensdomanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnKompetensdomanMouseClicked
       //Öppnar fönstret kompetensDoman.
        kompetensRuta.setVisible(true);
    }//GEN-LAST:event_btnKompetensdomanMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        //Öppnar fönstret för specialister och projektledare.
        specproj.setVisible(true);
    }//GEN-LAST:event_jButton1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HUB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HUB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HUB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HUB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HUB().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bakgrund;
    private javax.swing.JLabel Minimera;
    private javax.swing.JLabel Stäng;
    private javax.swing.JButton btnAnstallda;
    private javax.swing.JButton btnKompetensdoman;
    private javax.swing.JButton btnLoggaUt;
    private javax.swing.JButton btnSpelprojekt;
    private javax.swing.JLabel btnvisualbuttons;
    private javax.swing.JLabel drag;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}

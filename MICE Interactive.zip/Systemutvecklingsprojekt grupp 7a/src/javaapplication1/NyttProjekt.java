
package javaapplication1;
import javax.swing.JOptionPane;
import oru.inf.InfException;

public class NyttProjekt extends javax.swing.JFrame {
    
    public NyttProjekt() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfTitel = new javax.swing.JTextField();
        lblTitel = new javax.swing.JLabel();
        lblStartDatum = new javax.swing.JLabel();
        lblReleaseDatum = new javax.swing.JLabel();
        lblProjektledare = new javax.swing.JLabel();
        btnGaTillbaka = new javax.swing.JButton();
        tfStartDatum = new javax.swing.JTextField();
        tfReleaseDatum = new javax.swing.JTextField();
        tfProjektledare = new javax.swing.JTextField();
        btnSkapaProjekt = new javax.swing.JButton();
        cbWii = new javax.swing.JCheckBox();
        cbWiiU = new javax.swing.JCheckBox();
        cbNintendoDS = new javax.swing.JCheckBox();
        cbPlayStationPortable = new javax.swing.JCheckBox();
        cbPlayStation3 = new javax.swing.JCheckBox();
        cbXBox = new javax.swing.JCheckBox();
        cbXBox360 = new javax.swing.JCheckBox();
        cbAtari2600 = new javax.swing.JCheckBox();
        cbVectrex = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(640, 355));
        getContentPane().setLayout(null);

        tfTitel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfTitel);
        tfTitel.setBounds(120, 80, 110, 30);

        lblTitel.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblTitel.setForeground(new java.awt.Color(255, 255, 255));
        lblTitel.setText("Titel");
        getContentPane().add(lblTitel);
        lblTitel.setBounds(20, 80, 90, 30);

        lblStartDatum.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblStartDatum.setForeground(new java.awt.Color(255, 255, 255));
        lblStartDatum.setText("Start Datum");
        getContentPane().add(lblStartDatum);
        lblStartDatum.setBounds(20, 120, 100, 30);

        lblReleaseDatum.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblReleaseDatum.setForeground(new java.awt.Color(255, 255, 255));
        lblReleaseDatum.setText("Release Datum");
        getContentPane().add(lblReleaseDatum);
        lblReleaseDatum.setBounds(20, 160, 110, 30);

        lblProjektledare.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblProjektledare.setForeground(new java.awt.Color(255, 255, 255));
        lblProjektledare.setText("Projektledare");
        getContentPane().add(lblProjektledare);
        lblProjektledare.setBounds(20, 200, 120, 30);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(520, 40, 100, 30);

        tfStartDatum.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfStartDatum);
        tfStartDatum.setBounds(120, 120, 110, 30);

        tfReleaseDatum.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfReleaseDatum);
        tfReleaseDatum.setBounds(120, 160, 110, 30);

        tfProjektledare.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfProjektledare);
        tfProjektledare.setBounds(120, 200, 110, 30);

        btnSkapaProjekt.setBackground(new java.awt.Color(153, 204, 255));
        btnSkapaProjekt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnSkapaProjekt.setText("Skapa Projekt");
        btnSkapaProjekt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSkapaProjekt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSkapaProjektMouseClicked(evt);
            }
        });
        getContentPane().add(btnSkapaProjekt);
        btnSkapaProjekt.setBounds(120, 250, 110, 30);

        cbWii.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbWii.setForeground(new java.awt.Color(255, 255, 255));
        cbWii.setText("Wii");
        getContentPane().add(cbWii);
        cbWii.setBounds(260, 80, 70, 20);

        cbWiiU.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbWiiU.setForeground(new java.awt.Color(255, 255, 255));
        cbWiiU.setText("Wii U");
        getContentPane().add(cbWiiU);
        cbWiiU.setBounds(260, 100, 80, 20);

        cbNintendoDS.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbNintendoDS.setForeground(new java.awt.Color(255, 255, 255));
        cbNintendoDS.setText("Nintendo DS");
        getContentPane().add(cbNintendoDS);
        cbNintendoDS.setBounds(260, 120, 120, 20);

        cbPlayStationPortable.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbPlayStationPortable.setForeground(new java.awt.Color(255, 255, 255));
        cbPlayStationPortable.setText("PlayStation Portable");
        getContentPane().add(cbPlayStationPortable);
        cbPlayStationPortable.setBounds(260, 140, 160, 20);

        cbPlayStation3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbPlayStation3.setForeground(new java.awt.Color(255, 255, 255));
        cbPlayStation3.setText("PlayStation 3");
        getContentPane().add(cbPlayStation3);
        cbPlayStation3.setBounds(260, 160, 140, 20);

        cbXBox.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbXBox.setForeground(new java.awt.Color(255, 255, 255));
        cbXBox.setText("XBox");
        getContentPane().add(cbXBox);
        cbXBox.setBounds(260, 180, 80, 20);

        cbXBox360.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbXBox360.setForeground(new java.awt.Color(255, 255, 255));
        cbXBox360.setText("XBox 360");
        getContentPane().add(cbXBox360);
        cbXBox360.setBounds(260, 200, 100, 20);

        cbAtari2600.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbAtari2600.setForeground(new java.awt.Color(255, 255, 255));
        cbAtari2600.setText("Atari 2600");
        getContentPane().add(cbAtari2600);
        cbAtari2600.setBounds(260, 220, 110, 20);

        cbVectrex.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbVectrex.setForeground(new java.awt.Color(255, 255, 255));
        cbVectrex.setText("Vectrex");
        getContentPane().add(cbVectrex);
        cbVectrex.setBounds(260, 240, 90, 20);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Plattform");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(260, 60, 80, 10);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 0, 770, 380);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSkapaProjektMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSkapaProjektMouseClicked
       // Kontrollerar all inmatad information och lägger sedan till projektet.
       try
       {
        String sid = TestAvDB.getIDB().getAutoIncrement("SPELPROJEKT", "SID"); 
        String ProjLeadAID = TestAvDB.getIDB().fetchSingle("SELECT PROJEKTLEDARE.AID FROM PROJEKTLEDARE JOIN ANSTALLD ON ANSTALLD.AID = PROJEKTLEDARE.AID WHERE ANSTALLD.ANVNAMN ='"+ tfProjektledare.getText() +"'");
        String tabellFraga = "Insert into spelprojekt(SID, BETECKNING, STARTDATUM, RELEASEDATUM, AID) VALUES('" + sid + "','" + tfTitel.getText()+"','" + tfStartDatum.getText()+"','"+ tfReleaseDatum.getText()+"','"+ ProjLeadAID +"')";
        if(ProjLeadAID != null)
                {
                    if(!Validering.textNotEmpty2(tfTitel) || !Validering.textNotEmpty2(tfProjektledare) || !Validering.textNotEmpty2(tfReleaseDatum) || !Validering.textNotEmpty2(tfStartDatum))
                    {
                        JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma.");
                    }
                    else if(Validering.kontrolleraDatum(tfStartDatum.getText()) == false || Validering.kontrolleraDatum(tfReleaseDatum.getText()) == false)
                    {
                       JOptionPane.showMessageDialog(null, "Fel datum format. Exempel: 23.04.2018 (DD.MM.YYYY)");
                    }
                    else if(Validering.kontrolleraDatum(tfStartDatum.getText()) && Validering.kontrolleraDatum(tfReleaseDatum.getText()))
                    { 
                    TestAvDB.getIDB().insert(tabellFraga);
                    if(cbWii.isSelected())
                    {
                        int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'Wii'"));
                        String wii = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";
                        TestAvDB.getIDB().insert(wii);
                    }
                    if(cbWiiU.isSelected())
                    {
                        int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'Wii U'"));
                        String wiiU = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";
                        TestAvDB.getIDB().insert(wiiU);
                    }
                    if(cbNintendoDS.isSelected())
                    {
                        int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'Nintendo DS'"));
                        String nintendoDS = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";
                        TestAvDB.getIDB().insert(nintendoDS);
                    }
                    if(cbPlayStationPortable.isSelected())
                    {
                        int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'PlayStation Portable'"));
                        String playStationPortable = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";
                        TestAvDB.getIDB().insert(playStationPortable);
                    }
                    if(cbPlayStation3.isSelected())
                    {
                        int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'PlayStation 3'"));
                        String playStation3 = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";
                        TestAvDB.getIDB().insert(playStation3);
                    }
                    if(cbXBox.isSelected())
                    {
                       int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'XBox'"));
                        String xBox = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")"; 
                        TestAvDB.getIDB().insert(xBox);
                    }
                    if(cbXBox360.isSelected())
                    {
                    int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'XBox 360'"));
                        String xBox360 = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";  
                        TestAvDB.getIDB().insert(xBox360);
                    }
                    if(cbAtari2600.isSelected())
                    {
                    int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'Atari 2600'"));
                        String atari2600 = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")";  
                        TestAvDB.getIDB().insert(atari2600);
                    }
                    if(cbVectrex.isSelected())
                    {
                    int pid = Integer.parseInt(TestAvDB.getIDB().fetchSingle("select PID from plattform where benamning = 'Vectrex'"));
                        String vectrex = "insert into innefattar(SID,PID) values(" + sid + ", " + pid + ")"; 
                        TestAvDB.getIDB().insert(vectrex);
                    }
                    JOptionPane.showMessageDialog(null, "Projektet har skapats.");
                    }
       }
        else{
            
            Validering.felmeddelande("Personen är inte en projektledare. Uppdatera den anställdes roll för att lägga till individen som lead på ett projekt.");
        }
       }

       catch(InfException error)
       {
           System.out.println(error);
       }
    }//GEN-LAST:event_btnSkapaProjektMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NyttProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NyttProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NyttProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NyttProjekt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NyttProjekt().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnSkapaProjekt;
    private javax.swing.JCheckBox cbAtari2600;
    private javax.swing.JCheckBox cbNintendoDS;
    private javax.swing.JCheckBox cbPlayStation3;
    private javax.swing.JCheckBox cbPlayStationPortable;
    private javax.swing.JCheckBox cbVectrex;
    private javax.swing.JCheckBox cbWii;
    private javax.swing.JCheckBox cbWiiU;
    private javax.swing.JCheckBox cbXBox;
    private javax.swing.JCheckBox cbXBox360;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblProjektledare;
    private javax.swing.JLabel lblReleaseDatum;
    private javax.swing.JLabel lblStartDatum;
    private javax.swing.JLabel lblTitel;
    private javax.swing.JTextField tfProjektledare;
    private javax.swing.JTextField tfReleaseDatum;
    private javax.swing.JTextField tfStartDatum;
    private javax.swing.JTextField tfTitel;
    // End of variables declaration//GEN-END:variables
}

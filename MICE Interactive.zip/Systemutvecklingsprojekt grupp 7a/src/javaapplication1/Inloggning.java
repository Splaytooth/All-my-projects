
package javaapplication1;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.io.InputStream;

public class Inloggning extends javax.swing.JFrame {

    int xM;
    int yM; 
   
    private HUB nyHub;
    public Inloggning() 
    {
        //Instansierar rutan och sätter position samt storlek.
        initComponents();
        new TestAvDB();
        nyHub = new HUB();
        setLocation(600, 300);
        setSize(640, 360);
        
    }
    
   
        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tfNamn = new javax.swing.JTextField();
        btnLoggaIn = new javax.swing.JButton();
        tfLösenord = new javax.swing.JPasswordField();
        stäng = new javax.swing.JLabel();
        minimera = new javax.swing.JLabel();
        Logga = new javax.swing.JLabel();
        lblButtonsVisual = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        lblDrag = new javax.swing.JLabel();
        Bakgrund = new javax.swing.JLabel();
        lblAnvändarnamn = new javax.swing.JLabel();
        lblLösenord = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setUndecorated(true);
        getContentPane().setLayout(null);

        tfNamn.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 11)); // NOI18N
        tfNamn.setForeground(new java.awt.Color(153, 153, 153));
        tfNamn.setText("mbk");
        tfNamn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tfNamn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tfNamnMouseClicked(evt);
            }
        });
        getContentPane().add(tfNamn);
        tfNamn.setBounds(220, 190, 180, 30);

        btnLoggaIn.setBackground(new java.awt.Color(153, 204, 255));
        btnLoggaIn.setFont(new java.awt.Font("FrankRuehl", 1, 14)); // NOI18N
        btnLoggaIn.setText("Logga in");
        btnLoggaIn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnLoggaIn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLoggaInMouseClicked(evt);
            }
        });
        getContentPane().add(btnLoggaIn);
        btnLoggaIn.setBounds(220, 280, 100, 30);

        tfLösenord.setForeground(new java.awt.Color(153, 153, 153));
        tfLösenord.setText("tYp123");
        tfLösenord.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tfLösenord.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfLösenordFocusGained(evt);
            }
        });
        getContentPane().add(tfLösenord);
        tfLösenord.setBounds(220, 240, 180, 30);

        stäng.setAlignmentY(5.0F);
        stäng.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stängMouseClicked(evt);
            }
        });
        getContentPane().add(stäng);
        stäng.setBounds(617, 4, 10, 10);

        minimera.setText("jLabel3");
        minimera.setAlignmentY(5.0F);
        minimera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimeraMouseClicked(evt);
            }
        });
        getContentPane().add(minimera);
        minimera.setBounds(598, 4, 10, 10);

        Logga.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/Namnlöst-2.gif"))); // NOI18N
        Logga.setText("jLabel4");
        getContentPane().add(Logga);
        Logga.setBounds(-10, -60, 560, 330);

        lblButtonsVisual.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/Buttons.gif"))); // NOI18N
        lblButtonsVisual.setText("jLabel3");
        getContentPane().add(lblButtonsVisual);
        lblButtonsVisual.setBounds(0, -18, 670, 400);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 340, 640, 20);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 640, 20);

        lblDrag.setText("jLabel3");
        lblDrag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                lblDragMouseDragged(evt);
            }
        });
        lblDrag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblDragMousePressed(evt);
            }
        });
        getContentPane().add(lblDrag);
        lblDrag.setBounds(0, 0, 640, 20);

        Bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        Bakgrund.setText("s");
        getContentPane().add(Bakgrund);
        Bakgrund.setBounds(0, -10, 670, 370);

        lblAnvändarnamn.setBackground(new java.awt.Color(255, 255, 255));
        lblAnvändarnamn.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 14)); // NOI18N
        lblAnvändarnamn.setForeground(new java.awt.Color(204, 255, 255));
        lblAnvändarnamn.setText("Användarnamn");
        getContentPane().add(lblAnvändarnamn);
        lblAnvändarnamn.setBounds(90, 190, 110, 20);

        lblLösenord.setBackground(new java.awt.Color(255, 255, 255));
        lblLösenord.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 14)); // NOI18N
        lblLösenord.setForeground(new java.awt.Color(204, 255, 255));
        lblLösenord.setText("Lösenord");
        getContentPane().add(lblLösenord);
        lblLösenord.setBounds(130, 240, 90, 24);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoggaInMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLoggaInMouseClicked
     //Loggar in administratören efter att ha kontrollerat användarnamn och lösenord. Öppnar hub-rutan.
        String inNamn = tfNamn.getText();
       String inLosenord = tfLösenord.getText();
       Validering.textNotEmpty(tfNamn);
     if(Validering.textNotEmpty2(tfNamn))
     {
        Validering.textNotEmpty(tfLösenord);
     }
     if(Validering.textNotEmpty2(tfNamn) && Validering.textNotEmpty2(tfLösenord))
     {
        if(Validering.kontrolleraInlogg(inNamn, inLosenord) == true)
        {
           nyHub.setVisible(true);
           this.setVisible(false); 
        }
     }
    }//GEN-LAST:event_btnLoggaInMouseClicked

    private void lblDragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDragMouseDragged
        //Håller mus på plats när man drar runt på rutan.
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xM, y - yM);
    }//GEN-LAST:event_lblDragMouseDragged

    private void lblDragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDragMousePressed
      //Tillhör lblDragMouseDragged. Ger variablerna koordinater.
        xM = evt.getX();
       yM = evt.getY();
    }//GEN-LAST:event_lblDragMousePressed

    private void stängMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stängMouseClicked
        //Stänger programmet.
        System.exit(0);
    }//GEN-LAST:event_stängMouseClicked

    private void minimeraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimeraMouseClicked
       //Minimerar rutan.
        this.setState(Inloggning.ICONIFIED);
    }//GEN-LAST:event_minimeraMouseClicked

    private void tfLösenordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfLösenordFocusGained
        //Sätter färgen på lösenord-texten till svart om man klickar på den.
        tfLösenord.selectAll();
        tfLösenord.setForeground(Color.black);
    }//GEN-LAST:event_tfLösenordFocusGained

    private void tfNamnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfNamnMouseClicked
       //Sätter färgen på anvädarnamn-texten till svart om man klickar på den.
        tfNamn.selectAll();
        tfNamn.setForeground(Color.black);
    }//GEN-LAST:event_tfNamnMouseClicked


    @Override
    public void setVisible(boolean bln) {
        super.setVisible(bln); 
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bakgrund;
    private javax.swing.JLabel Logga;
    private javax.swing.JButton btnLoggaIn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblAnvändarnamn;
    private javax.swing.JLabel lblButtonsVisual;
    private javax.swing.JLabel lblDrag;
    private javax.swing.JLabel lblLösenord;
    private javax.swing.JLabel minimera;
    private javax.swing.JLabel stäng;
    private javax.swing.JPasswordField tfLösenord;
    private javax.swing.JTextField tfNamn;
    // End of variables declaration//GEN-END:variables

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inloggning.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inloggning.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inloggning.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inloggning.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            new Inloggning().setVisible(true);
            }
        });
    }
}



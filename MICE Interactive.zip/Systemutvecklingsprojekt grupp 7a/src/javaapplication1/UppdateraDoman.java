
package javaapplication1;
import javax.swing.*;
import oru.inf.InfException;

public class UppdateraDoman extends javax.swing.JFrame {

   
    public UppdateraDoman() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfTidigareBenamning = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnUppdateraDoman = new javax.swing.JButton();
        tfNyBenamning = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnGaTillbaka = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taBeskrivning = new javax.swing.JTextArea();
        bakgrund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        tfTidigareBenamning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfTidigareBenamning);
        tfTidigareBenamning.setBounds(130, 60, 190, 30);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Beskrivning");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 140, 70, 20);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Ny benämning");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 90, 110, 40);

        btnUppdateraDoman.setBackground(new java.awt.Color(153, 204, 255));
        btnUppdateraDoman.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnUppdateraDoman.setText("Uppdatera Domän");
        btnUppdateraDoman.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnUppdateraDoman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUppdateraDomanMouseClicked(evt);
            }
        });
        getContentPane().add(btnUppdateraDoman);
        btnUppdateraDoman.setBounds(130, 270, 140, 30);

        tfNyBenamning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfNyBenamning);
        tfNyBenamning.setBounds(130, 100, 190, 30);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tidigare benämning");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 50, 110, 40);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 960, 20);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 330, 960, 20);

        btnGaTillbaka.setBackground(new java.awt.Color(153, 153, 255));
        btnGaTillbaka.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnGaTillbaka.setText("Gå Tillbaka");
        btnGaTillbaka.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGaTillbaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGaTillbakaMouseClicked(evt);
            }
        });
        getContentPane().add(btnGaTillbaka);
        btnGaTillbaka.setBounds(500, 40, 120, 30);

        taBeskrivning.setColumns(20);
        taBeskrivning.setRows(5);
        taBeskrivning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(taBeskrivning);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(130, 140, 290, 120);

        bakgrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/loopingsnow.gif.gif"))); // NOI18N
        getContentPane().add(bakgrund);
        bakgrund.setBounds(0, 0, 660, 360);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnUppdateraDomanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUppdateraDomanMouseClicked
        //Kontrollerar inmatat information och uppdaterar därefter den valda domänen.
        try
        {
            if(!Validering.textNotEmpty2(tfNyBenamning) || !Validering.textNotEmpty2(tfTidigareBenamning))
            {
                JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma.");
            }
            else
            {
         String kollaBenamning = "Select benamning from kompetensdoman where lower(benamning) = '" + tfTidigareBenamning.getText().toLowerCase() + "'";
            if(!Validering.textNotEmpty2(tfTidigareBenamning))
            {
                JOptionPane.showMessageDialog(null, "Ett eller flera fält är tomma");
            }
            else if(tfTidigareBenamning.getText().equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(kollaBenamning)))
            {
                String uppdatera = "update KOMPETENSDOMAN set KOMPETENSDOMAN.BENAMNING = '" + tfNyBenamning.getText() + "', KOMPETENSDOMAN.BESKRIVNING = '" 
                + taBeskrivning.getText() + "' where KOMPETENSDOMAN.benamning = '" + tfTidigareBenamning.getText() + "'" ;
                System.out.println(uppdatera);
                TestAvDB.getIDB().update(uppdatera);
                JOptionPane.showMessageDialog(null, "Kompetensdomänen " + tfTidigareBenamning.getText() + " har ändrats till " + tfNyBenamning.getText());
                setVisible(false);
            }
            else if(!tfTidigareBenamning.getText().equalsIgnoreCase(TestAvDB.getIDB().fetchSingle(kollaBenamning)))
            {
              JOptionPane.showMessageDialog(null, "Hittade ingen domän med benämningen: " + tfTidigareBenamning.getText());
            }
        }
            
        }
        catch(InfException error)
        {
            System.out.println(error);
        }
    }//GEN-LAST:event_btnUppdateraDomanMouseClicked

    private void btnGaTillbakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGaTillbakaMouseClicked
        //Stänger akttuella fönstret.
        setVisible(false);
    }//GEN-LAST:event_btnGaTillbakaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UppdateraDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UppdateraDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UppdateraDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UppdateraDoman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UppdateraDoman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bakgrund;
    private javax.swing.JButton btnGaTillbaka;
    private javax.swing.JButton btnUppdateraDoman;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taBeskrivning;
    private javax.swing.JTextField tfNyBenamning;
    private javax.swing.JTextField tfTidigareBenamning;
    // End of variables declaration//GEN-END:variables
}

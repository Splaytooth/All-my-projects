﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TigerLineOfSight : MonoBehaviour{

    private TigerAI tigerAI;
    
    void Awake()
    {
        tigerAI = gameObject.GetComponentInParent<TigerAI>();
    }

    void OnTriggerStay2D(Collider2D other)
    {
        // If the character stays within the collider the tiger will get its position and follow it.
        if (other.CompareTag("Character"))
        {
           tigerAI.target = other.gameObject;
            tigerAI.following = true;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        // If the character leaves the collider the tiger will stop following.
        if (other.CompareTag("Character"))
        {
            tigerAI.following = false;
        }
    }
}
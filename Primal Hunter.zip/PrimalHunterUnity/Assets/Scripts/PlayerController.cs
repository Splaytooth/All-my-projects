﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    private float maxSpeed = 10f;
    private float jumpHeight = 15f;
    public bool facingRight = true;
    Animator anim;
    bool grounded = false;
    public Transform groundCheck;
    float groundRadius = 0.2f;
    public LayerMask whatIsGround;

    void Awake () 
	{
        anim = GetComponent<Animator>();
	}

    void Update()
    {
        // Regularly checks if the character is grounded and if the jump button has been pressed before it proceeds to jump.
        if (grounded && Input.GetButtonDown("Jump"))
        {
            Jump();
        }
    }
 
    void FixedUpdate ()
    {
        // Regularly checks if the character is grounded. 
        grounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);
        anim.SetBool("Ground", grounded);

        // Sends the characters Y axis velocity to the animator for the blend tree animation.
        anim.SetFloat("vSpeed", GetComponent<Rigidbody2D>().velocity.y);

        // Is ran regularly to check if the player wants to move the character.
        Move ();
	}

    // Makes the character jump.
	void Jump()
	{
	    anim.SetBool("Ground", false);
        GetComponent<Rigidbody2D>().velocity = new Vector2(0, jumpHeight);
	}

    // Makes the character move.
	void Move()
	{
        // Checks for the players input and makes the character move.
		float move = Input.GetAxis("Horizontal");
        anim.SetFloat("Speed", Mathf.Abs(move));
		GetComponent<Rigidbody2D>().velocity = new Vector2(move * maxSpeed, GetComponent<Rigidbody2D>().velocity.y);

        // Flips the character sprite depending on direction he is moving.
		if (move > 0 && !facingRight)
			Flip();
		else if (move < 0 && facingRight)
			Flip();

        // Slows down the character when he is attacking on the ground.
        if (anim.GetBool("Attacking") == true && grounded)
        {
            if (facingRight && GetComponent<Rigidbody2D>().velocity.x > 2)
                GetComponent<Rigidbody2D>().AddForce(new Vector2(-100, GetComponent<Rigidbody2D>().velocity.y));
            else if (!facingRight && GetComponent<Rigidbody2D>().velocity.x < -2)
                GetComponent<Rigidbody2D>().AddForce(new Vector2(100, GetComponent<Rigidbody2D>().velocity.y));
        }
    }

    // Flips the character.
	void Flip()
	{
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}
}
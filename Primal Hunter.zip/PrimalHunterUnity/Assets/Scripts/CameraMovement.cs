﻿using UnityEngine;

public class CameraMovement : MonoBehaviour {

    public Transform player;
    public Vector3 offset;

    void Update ()
    {
        // Makes the camera follow the character. The Y and Z axis is fixed.
        transform.position = new Vector3(player.position.x + offset.x, offset.y, offset.z);
    }
}

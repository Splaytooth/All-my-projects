﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour {

    public bool pauseDisabled;
    public bool isPaused;
    public GameObject pauseMenuCanvas;

    void Update()
    {
        // Checks if the player paused the game.
        if (isPaused)
        {
            pauseMenuCanvas.SetActive(true);
            Time.timeScale = 0f;
        }
        else if(isPaused == false && pauseDisabled != true)
        {
            pauseMenuCanvas.SetActive(false);
            Time.timeScale = 1f;
        }
        if (Input.GetKeyDown(KeyCode.Escape) && pauseDisabled != true)
            isPaused = !isPaused;
    }

    // Resumes the game.
    public void Resume()
    {
        isPaused = false;
    }

    // Restarts the active level.
    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // Loads the main menu.
    public void MainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    // Quits the application.
    public void Quit()
    {
        Application.Quit();
    }
}
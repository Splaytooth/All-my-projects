﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject deathScreenCanvas;
    public GameObject levelEndCanvas;
    
	void OnCollisionEnter2D(Collision2D collObject)
    {
        // Controls which game objects the character collides with, if it's the deathzone the gameover screen loads.
        if (collObject.gameObject.name == "DeathZone")
            GameOver();

        // Controls which game objects the character collides with, if it's the levelendzone the levelcomplete screen loads.
        else if (collObject.gameObject.name == "LevelEndZone")
            LevelComplete();
    }

    // Toggles the gameover screen and starts the countdown method. First line makes sure you cant pause while in the gameover screen.
    public void GameOver()
    {
        GameObject.Find("PauseMenu").GetComponent<PauseMenu>().pauseDisabled = true;
        deathScreenCanvas.SetActive(true);
        StartCoroutine(Countdown(true));
    }

    // Toggles the levelcomplete screen and starts the countdown method. First line makes sure you cant pause while in the levelcomplete screen.
    public void LevelComplete()
    {
        GameObject.Find("PauseMenu").GetComponent<PauseMenu>().pauseDisabled = true;
        levelEndCanvas.SetActive(true);
        StartCoroutine(Countdown(false));
    }

    // A simple timer used during the gameover and levelcomplete screen.
    private IEnumerator Countdown(bool endAction)
    {
        Time.timeScale = 0f;
        float pauseEndTime = Time.realtimeSinceStartup + 2;

        while (Time.realtimeSinceStartup < pauseEndTime)
        {
            yield return 0;
        }
        Time.timeScale = 1;

        if(endAction == true)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            GameObject.Find("PauseMenu").GetComponent<PauseMenu>().pauseDisabled = false;
        }
        else if(endAction == false)
        {
            SceneManager.LoadScene("MainMenu");
            GameObject.Find("PauseMenu").GetComponent<PauseMenu>().pauseDisabled = false;
        }
    }
}
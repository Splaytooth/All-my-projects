﻿using UnityEngine;

public class CharacterAttackTrigger : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D col)
    {
        // If the character attacks an GameObject with the tag "Enemy" it is destroyed.
        if (col.isTrigger != true && col.CompareTag("Enemy"))
        {
            Destroy(col.gameObject);
        }
    }
}
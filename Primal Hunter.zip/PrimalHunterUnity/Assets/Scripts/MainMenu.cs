﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {

    // Starts the level.
	public void LoadLevel()
    {
        SceneManager.LoadScene("Level");
    }

    // Quits the application.
    public void QuitGame()
    {
        Application.Quit();
    }
}

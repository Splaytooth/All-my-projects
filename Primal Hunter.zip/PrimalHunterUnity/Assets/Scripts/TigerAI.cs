﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TigerAI : MonoBehaviour {

    private Animator anim;
    public AudioSource attackSound;
    public GameObject target;
    public bool following;
    private float speed;

    void Awake()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    void Update()
    {
        // Regularly checks if the tiger is following the character and sends its speed to the animator.
        if (following == true)
        {
            Follow();
            anim.SetFloat("Speed", Mathf.Abs(speed));
        }
        else if(following == false)
        {
            speed = 0;
            anim.SetFloat("Speed", Mathf.Abs(speed));
        }
    }

    void OnCollisionEnter2D(Collision2D collObject)
    {
        // Controls which game objects the tiger collides with, if it's the deathzone the tiger dies.
        if (collObject.gameObject.name == "DeathZone")
            Destroy(gameObject);
    }

    // Plays the attack animation and sound.
    public void Attack()
    {
        anim.SetTrigger("Attacking");
        attackSound.Play();
    }

    // Makes the tiger follow the character depending on if the character is to the left or right.
    public void Follow()
    {
        float tigerPosition = GetComponent<Transform>().position.x;
        float playerPostion = target.GetComponent<Transform>().position.x;
        float leftOrRight = tigerPosition - playerPostion;

            if (leftOrRight < 0)
            {
                speed = 10f;
                GetComponent<Rigidbody2D>().velocity = new Vector2(speed, GetComponent<Rigidbody2D>().velocity.y);
                if (transform.localScale.x > 0)
                    Flip();
            }
            else if (leftOrRight > 0)
            {
                speed = -10f;
                GetComponent<Rigidbody2D>().velocity = new Vector2(speed, GetComponent<Rigidbody2D>().velocity.y);
                if (transform.localScale.x < 0)
                    Flip();
            }
    }

    // Flips the tiger.
    public void Flip()
    {
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}
﻿using UnityEngine;

public class TigerAttackTrigger : MonoBehaviour {

    private bool attacking = false;
    private float attackTimer = 0;
    private float attackCooldown = 0.2f;

    void OnTriggerStay2D(Collider2D col)
    {
        // When the character enters this collider the Attack() method is called and if the character stays within the collider for a certain amount of time then the GameOver() method is called.
        if (col.isTrigger != true && col.CompareTag("Character"))
        {
            if (attacking == false)
            {
                attacking = true;
                attackTimer = attackCooldown;
                TigerAI tigerAI = gameObject.GetComponentInParent(typeof(TigerAI)) as TigerAI;
                tigerAI.Attack();
            }

            if (attackTimer > 0)
            {
                attackTimer -= Time.deltaTime;
            }
            if (attackTimer <= 0)
            {
               GameObject.Find("Character").GetComponent<GameManager>().GameOver();
            }
        }
    }

    void OnTriggerExit2D(Collider2D col)
    {
        // Prevents the tiger from attacking if the character is out of range.
        if (col.CompareTag("Character"))
        {
            attacking = false;
        }
    }
}

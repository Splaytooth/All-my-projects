﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    private float maxSpeed = 10f;
    private float jumpForce = 400f;

	// Use this for initialization
	void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {
        CharacterController controller = GetComponent<CharacterController>();
            if (Input.GetButtonDown("Jump"))
            if (controller.isGrounded == false)
                GetComponent<Rigidbody2D>().AddForce(new Vector2(0, jumpForce));
    }
	
	void FixedUpdate ()
    {
        float move = Input.GetAxis("Horizontal");
        GetComponent<Rigidbody2D>().velocity = new Vector2(move * maxSpeed, GetComponent<Rigidbody2D>().velocity.y);
	}
}